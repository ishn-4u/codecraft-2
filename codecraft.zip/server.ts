import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Google Gemini AI client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Fault Analysis endpoint
app.post('/api/fault-analysis', async (req, res) => {
  const { challengeTitle, instructions, expectedGoal, userCode, failingTests } = req.body;

  const defaultFallback = {
    success: true,
    faultSummary: failingTests?.[0]?.faultMessage || failingTests?.[0]?.title || "Check your code syntax and structure.",
    beginnerExplanation: failingTests?.[0]?.explanation || "Computers are very strict about syntax. Even a single missing character like a quote, bracket, or closing tag can stop your code from working as expected.",
    analogy: "Like sending a letter without a stamp or forgetting to close the front door!",
    actionableTip: failingTests?.[0]?.hint || "Compare your code against the challenge instructions line by line.",
    revealedFix: failingTests?.[0]?.hint || "Double-check tags and syntax."
  };

  if (!ai) {
    return res.json(defaultFallback);
  }

  try {
    const prompt = `You are a patient, encouraging coding tutor for absolute beginners who have zero programming experience.
A beginner student is stuck on a coding challenge.

CHALLENGE: "${challengeTitle}"
INSTRUCTIONS:
${instructions}

EXPECTED GOAL:
${expectedGoal}

STUDENT'S CURRENT CODE:
HTML:
${userCode?.html || 'N/A'}

CSS:
${userCode?.css || 'N/A'}

JAVASCRIPT:
${userCode?.js || 'N/A'}

FAILED AUTOMATED TEST(S):
${JSON.stringify(failingTests, null, 2)}

TASK:
1. Identify the exact fault or mistake in the student's code (e.g. unclosed tag, misspelled tag or class, missing attribute, missing quote, missing semicolon, case-sensitivity typo, wrong logic, DOM selector mistake).
2. Explain the mistake gently in simple everyday terms without harsh jargon.
3. Provide a helpful real-world analogy.
4. Give an actionable hint on how to fix it without immediately copying the full answer.
5. Provide a minimal one-line code snippet showing the corrected line.

Return ONLY a valid JSON object matching this schema:
{
  "faultSummary": "Short 1-sentence pinpointing the exact fault",
  "beginnerExplanation": "2-3 sentences explaining why it failed and what the browser expects",
  "analogy": "A friendly 1-sentence real-world analogy",
  "actionableTip": "Concrete step-by-step guidance on what to change",
  "revealedFix": "Short snippet of the corrected line or syntax"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json({ success: true, ...parsed });
  } catch (error: any) {
    console.error('Error generating AI fault analysis, returning rule-based diagnostic:', error);
    return res.json(defaultFallback);
  }
});

// Setup Vite middleware for development or serve dist for production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CodeCraft learning platform running at http://localhost:${PORT}`);
  });
}

startServer();
