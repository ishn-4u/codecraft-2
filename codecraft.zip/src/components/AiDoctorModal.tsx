import React, { useState } from 'react';
import { Sparkles, X, Lightbulb, Compass, CheckCircle2, ChevronRight, Eye, EyeOff } from 'lucide-react';
import { FaultAnalysisResult } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';

interface AiDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: FaultAnalysisResult | null;
  isLoading: boolean;
  challengeTitle: string;
}

export const AiDoctorModal: React.FC<AiDoctorModalProps> = ({
  isOpen,
  onClose,
  result,
  isLoading,
  challengeTitle,
}) => {
  const [showFixSnippet, setShowFixSnippet] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-scaleUp">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-indigo-950 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/50 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                AI Fault Doctor
                <span className="text-[10px] font-medium px-2 py-0.2 rounded-full bg-indigo-500/20 text-indigo-300">
                  Gemini 3.8 Flash
                </span>
              </h3>
              <p className="text-xs text-slate-400 truncate max-w-xs">{challengeTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-10 h-10 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm font-semibold text-slate-300">Examining your code line-by-line...</p>
              <p className="text-xs text-slate-500 max-w-xs">
                Analyzing syntax, tags, and logic to pinpoint the exact fault for beginners.
              </p>
            </div>
          ) : result ? (
            <div className="space-y-4">
              {/* Fault Summary */}
              <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/60">
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400 block mb-1">
                  Primary Fault Detected
                </span>
                <p className="text-sm font-semibold text-rose-100">{result.faultSummary}</p>
              </div>

              {/* Beginner Explanation */}
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-1.5">
                <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-indigo-400" />
                  Understanding the Concept
                </span>
                <MarkdownRenderer
                  content={result.beginnerExplanation}
                  variant="explanation"
                  className="text-slate-300"
                />
              </div>

              {/* Analogy */}
              {result.analogy && (
                <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-800/40 text-xs text-amber-200/90 flex items-start gap-2.5">
                  <span className="text-base select-none">💡</span>
                  <div>
                    <span className="font-bold text-amber-300">Think of it like this: </span>
                    <span>{result.analogy}</span>
                  </div>
                </div>
              )}

              {/* Actionable Tip */}
              <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-800/40 space-y-1">
                <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  How to Fix Your Code
                </span>
                <MarkdownRenderer
                  content={result.actionableTip}
                  variant="fix"
                  className="text-slate-200"
                />
              </div>

              {/* Optional Fix Snippet Spoiler */}
              {result.revealedFix && (
                <div className="pt-2 border-t border-slate-800">
                  <button
                    onClick={() => setShowFixSnippet(!showFixSnippet)}
                    className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition"
                  >
                    {showFixSnippet ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showFixSnippet ? 'Hide code snippet' : 'Peek at the corrected line'}</span>
                  </button>

                  {showFixSnippet && (
                    <div className="mt-2 p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto whitespace-pre">
                      {result.revealedFix}
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="py-8 text-center text-slate-400 text-sm">
              No diagnosis available. Try running your tests again!
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-md shadow-indigo-600/30"
          >
            Got It! Back to Code
          </button>
        </div>
      </div>
    </div>
  );
};
