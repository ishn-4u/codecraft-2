import React, { useState } from 'react';
import {
  Flame,
  Sparkles,
  BookOpen,
  Code2,
  Award,
  ChevronDown,
  MapPin,
  Volume2,
  VolumeX,
  LogIn,
  LogOut,
  Cloud,
  User as UserIcon,
  RefreshCw,
} from 'lucide-react';
import { StreakData, TrackId } from '../types';
import { calculateLevel } from '../utils/streakManager';
import { TRACK_METADATA } from '../data/curriculum';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  currentTrackId: TrackId;
  onSelectTrack: (trackId: TrackId) => void;
  streakData: StreakData;
  onOpenStreakModal: () => void;
  onOpenGlossary: () => void;
  onOpenSandbox: () => void;
  onOpenRoadmap: () => void;
  onToggleSidebar: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTrackId,
  onSelectTrack,
  streakData,
  onOpenStreakModal,
  onOpenGlossary,
  onOpenSandbox,
  onOpenRoadmap,
  onToggleSidebar,
  isMuted,
  onToggleMute,
  onOpenAuthModal,
}) => {
  const { user, isSigningIn, signOut } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const levelInfo = calculateLevel(streakData.totalXp);
  const currentTrack = TRACK_METADATA[currentTrackId];

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 text-white px-3 sm:px-4 flex items-center justify-between z-20 shrink-0">
      {/* Left: Brand & Track Selector */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={onToggleSidebar}
          className="flex items-center gap-2.5 font-extrabold text-lg tracking-tight group hover:opacity-90 transition cursor-pointer"
          title="Toggle Curriculum Menu"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/25">
            <Code2 className="w-5 h-5 text-white" />
          </div>
          <span className="hidden sm:inline bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
            CodeCraft
          </span>
        </button>

        <div className="h-5 w-px bg-slate-800 hidden md:block" />

        {/* Track dropdown */}
        <div className="relative group">
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-xs sm:text-sm font-medium text-slate-200 transition cursor-pointer">
            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
            <span className="truncate max-w-[130px] sm:max-w-[190px]">{currentTrack.title.split(':')[0]}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Dropdown Menu */}
          <div className="absolute left-0 top-full mt-1.5 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all z-50">
            <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Select Curriculum Track
            </div>
            {(Object.keys(TRACK_METADATA) as TrackId[]).map((id) => {
              const meta = TRACK_METADATA[id];
              const isSelected = currentTrackId === id;
              return (
                <button
                  key={id}
                  onClick={() => onSelectTrack(id)}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition cursor-pointer ${
                    isSelected ? 'text-indigo-400 font-semibold bg-indigo-950/40' : 'text-slate-300'
                  }`}
                >
                  <span>{meta.title}</span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Roadmap button */}
        <button
          onClick={onOpenRoadmap}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 border border-slate-700/50 text-xs font-semibold text-indigo-300 transition cursor-pointer"
          title="Full-Stack Learning Skill Tree"
        >
          <MapPin className="w-3.5 h-3.5 text-indigo-400" />
          <span>Skill Tree</span>
        </button>
      </div>

      {/* Right: Gamification Badges & Tools */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Sound Toggle */}
        <button
          onClick={onToggleMute}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          title={isMuted ? 'Unmute Audio Feedback' : 'Mute Audio Feedback'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-slate-300" />}
        </button>

        {/* Daily Streak Flame */}
        <button
          onClick={onOpenStreakModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs sm:text-sm font-bold transition group cursor-pointer"
          title="Daily Streak - Click to view calendar and freezes"
        >
          <Flame className="w-4 h-4 text-amber-500 fill-amber-500 animate-bounce group-hover:scale-110 transition-transform" />
          <span>{streakData.currentStreak} Day{streakData.currentStreak === 1 ? '' : 's'}</span>
        </button>

        {/* Level / XP Pill */}
        <button
          onClick={onOpenStreakModal}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-xs text-slate-300 transition cursor-pointer"
          title={`Total XP: ${streakData.totalXp} XP (${levelInfo.title})`}
        >
          <Award className="w-4 h-4 text-purple-400" />
          <span className="font-semibold text-slate-200">Lvl {levelInfo.level}</span>
          <span className="text-purple-400 font-bold">{streakData.totalXp} XP</span>
        </button>

        {/* Zero-to-Hero Glossary Button */}
        <button
          onClick={onOpenGlossary}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-300 transition cursor-pointer"
          title="Zero-Knowledge Beginner Glossary"
        >
          <BookOpen className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden lg:inline">Glossary</span>
        </button>

        {/* Free Code Sandbox */}
        <button
          onClick={onOpenSandbox}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition cursor-pointer"
          title="Free Playground Sandbox"
        >
          <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
          <span className="hidden md:inline">Playground</span>
        </button>

        <div className="h-5 w-px bg-slate-800" />

        {/* Firebase Authentication (Google Sign-In) */}
        {user ? (
          <div className="relative">
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2 p-1 pl-2 pr-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 transition cursor-pointer"
              title={`${user.displayName || user.email} (Cloud Synced)`}
            >
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'User'}
                  className="w-7 h-7 rounded-lg object-cover ring-1 ring-emerald-500/50"
                />
              ) : (
                <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-xs text-white">
                  {(user.displayName || user.email || 'U')[0].toUpperCase()}
                </div>
              )}
              <span className="text-xs font-medium text-slate-200 hidden xl:inline max-w-[100px] truncate">
                {user.displayName?.split(' ')[0] || 'Coder'}
              </span>
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
            </button>

            {/* User Dropdown */}
            {userDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                <div className="px-3 py-2 border-b border-slate-800">
                  <div className="text-xs font-bold text-white truncate">{user.displayName || 'Coder'}</div>
                  <div className="text-[11px] text-slate-400 truncate">{user.email}</div>
                  <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1 font-semibold">
                    <Cloud className="w-3 h-3" /> Firestore Cloud Persistence Active
                  </div>
                </div>

                <button
                  onClick={() => {
                    setUserDropdownOpen(false);
                    onOpenAuthModal();
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-indigo-300 hover:bg-slate-800 flex items-center gap-2 transition cursor-pointer"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  <span>Cloud Sync Details</span>
                </button>

                <button
                  onClick={async () => {
                    setUserDropdownOpen(false);
                    await signOut();
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-rose-300 hover:bg-slate-800 flex items-center gap-2 transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={onOpenAuthModal}
            disabled={isSigningIn}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-900 text-xs font-black shadow-md shadow-white/10 transition active:scale-95 cursor-pointer disabled:opacity-75"
            title="Sign in with Google to sync your streak & progress across devices"
          >
            {isSigningIn ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-900" />
            ) : (
              <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
            )}
            <span>{isSigningIn ? 'Connecting...' : 'Sign In'}</span>
          </button>
        )}
      </div>
    </header>
  );
};
