import React from 'react';
import { X, CheckCircle2, Trophy, Sparkles, ArrowRight, Lock, MapPin, Star } from 'lucide-react';
import { Lesson, TrackId, StreakData } from '../types';
import { LESSONS, TRACK_METADATA } from '../data/curriculum';

interface RoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLessonId: string;
  onSelectLesson: (id: string) => void;
  streakData: StreakData;
}

export const RoadmapModal: React.FC<RoadmapModalProps> = ({
  isOpen,
  onClose,
  currentLessonId,
  onSelectLesson,
  streakData,
}) => {
  if (!isOpen) return null;

  const tracks: TrackId[] = ['html', 'css', 'javascript', 'frontend', 'backend'];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-scaleUp">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center">
              <MapPin className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Full-Stack Learning Skill Tree</h3>
              <p className="text-xs text-slate-400">Your interactive roadmap from zero to production ready</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Roadmap Nodes List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-8">
          {tracks.map((trackId, trackIdx) => {
            const meta = TRACK_METADATA[trackId];
            const trackLessons = LESSONS.filter((l) => l.trackId === trackId);
            const completedCount = trackLessons.filter((l) =>
              streakData.completedLessonIds.includes(l.id)
            ).length;
            const isAllDone = completedCount === trackLessons.length && trackLessons.length > 0;

            return (
              <div key={trackId} className="relative space-y-3">
                {/* Connecting track line */}
                {trackIdx < tracks.length - 1 && (
                  <div className="absolute left-6 top-12 bottom-[-24px] w-0.5 bg-slate-800 -z-10" />
                )}

                {/* Track Node Header */}
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm shrink-0 shadow-lg ${
                      isAllDone
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {isAllDone ? <Trophy className="w-6 h-6" /> : `0${trackIdx + 1}`}
                  </div>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                      Phase {trackIdx + 1}
                    </div>
                    <div className="text-base font-extrabold text-white flex items-center gap-2">
                      <span>{meta.title}</span>
                      {isAllDone && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                          Mastered
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">{meta.description}</div>
                  </div>
                </div>

                {/* Lessons Grid in this Track */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pl-4 sm:pl-14">
                  {trackLessons.map((lesson) => {
                    const isDone = streakData.completedLessonIds.includes(lesson.id);
                    const isCurrent = lesson.id === currentLessonId;
                    const isProject = lesson.category === 'project';

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => {
                          onSelectLesson(lesson.id);
                          onClose();
                        }}
                        className={`p-3 rounded-xl border text-left flex flex-col justify-between transition group relative ${
                          isCurrent
                            ? 'bg-indigo-600/30 border-indigo-400 shadow-md shadow-indigo-600/20 ring-1 ring-indigo-400'
                            : isDone
                            ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 text-slate-200'
                            : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-850 text-slate-400'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-1 mb-2">
                          <span className="text-[10px] font-semibold text-slate-500">
                            {isProject ? 'Capstone Project' : `Lesson ${lesson.order}`}
                          </span>
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : isCurrent ? (
                            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                          ) : null}
                        </div>

                        <div className="text-xs font-bold text-white group-hover:text-indigo-300 transition line-clamp-2">
                          {lesson.title}
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800/80">
                          <span>+{lesson.xpReward} XP</span>
                          <span className="flex items-center gap-1 group-hover:translate-x-0.5 transition-transform text-indigo-400 font-semibold text-[10px]">
                            {isCurrent ? 'Current' : 'Go'} <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
