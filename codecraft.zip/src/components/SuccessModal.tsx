import React from 'react';
import { Trophy, ArrowRight, Flame, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';
import { Lesson, Badge } from '../types';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNextLesson: () => void;
  lesson: Lesson;
  newlyEarnedBadges: Badge[];
  streakDays: number;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({
  isOpen,
  onClose,
  onNextLesson,
  lesson,
  newlyEarnedBadges,
  streakDays,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-scaleUp text-center p-6 space-y-5">
        {/* Celebration Trophy Icon */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 mx-auto flex items-center justify-center shadow-lg shadow-amber-500/30">
          <Trophy className="w-9 h-9 text-slate-950" />
        </div>

        {/* Title & Lesson Info */}
        <div className="space-y-1">
          <h2 className="text-xl font-black text-white">Challenge Completed!</h2>
          <p className="text-xs text-slate-400">"{lesson.title}"</p>
        </div>

        {/* Rewards Grid */}
        <div className="grid grid-cols-2 gap-3 py-1">
          <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-800/40 text-center">
            <div className="text-[11px] font-semibold text-indigo-300 uppercase">XP Earned</div>
            <div className="text-xl font-black text-white mt-0.5">+{lesson.xpReward} XP</div>
          </div>

          <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/40 text-center">
            <div className="text-[11px] font-semibold text-amber-300 uppercase">Daily Streak</div>
            <div className="text-xl font-black text-amber-400 mt-0.5 flex items-center justify-center gap-1">
              <Flame className="w-5 h-5 fill-amber-400" />
              {streakDays} Day{streakDays === 1 ? '' : 's'}
            </div>
          </div>
        </div>

        {/* Newly Unlocked Badge (if any) */}
        {newlyEarnedBadges.length > 0 && (
          <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border border-amber-500/30 text-left flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl shrink-0">
              🏆
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                New Badge Unlocked!
              </div>
              <div className="text-xs font-bold text-white">{newlyEarnedBadges[0].title}</div>
              <div className="text-[10px] text-slate-400">{newlyEarnedBadges[0].description}</div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => {
              onClose();
              onNextLesson();
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-extrabold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition active:scale-98"
          >
            <span>Continue to Next Challenge</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="w-full py-2 rounded-xl text-xs text-slate-400 hover:text-white transition"
          >
            Stay and Experiment with Code
          </button>
        </div>
      </div>
    </div>
  );
};
