import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lightbulb,
  Sparkles,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Eye,
  KeyRound,
  ArrowRight,
  Play,
} from 'lucide-react';
import { Lesson, TestResult } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';

interface FaultInspectorProps {
  lesson: Lesson;
  testResults: TestResult[];
  allPassed: boolean;
  hasRunTests: boolean;
  onAskAiDoctor: () => void;
  isLoadingAi: boolean;
  onNextLesson?: () => void;
  onShowSolution?: () => void;
  onRun: () => void;
  isRunning: boolean;
}

export const FaultInspector: React.FC<FaultInspectorProps> = ({
  lesson,
  testResults,
  allPassed,
  hasRunTests,
  onAskAiDoctor,
  isLoadingAi,
  onNextLesson,
  onShowSolution,
  onRun,
  isRunning,
}) => {
  const [activeHintIndex, setActiveHintIndex] = useState<number | null>(null);
  const [isSolutionRevealed, setIsSolutionRevealed] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  // Find the first failing test to highlight the primary fault
  const firstFault = testResults.find((r) => !r.passed);
  const passingCount = testResults.filter((r) => r.passed).length;
  const totalCount = lesson.tests.length;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl flex flex-col shrink-0">
      {/* Inspector Header / Status Bar */}
      <div
        className={`px-4 py-3 flex items-center justify-between border-b cursor-pointer select-none transition ${
          !hasRunTests
            ? 'bg-slate-850 border-slate-800 text-slate-300'
            : allPassed
            ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
            : 'bg-rose-950/60 border-rose-800/80 text-rose-300'
        }`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2.5">
          {!hasRunTests ? (
            <HelpCircle className="w-5 h-5 text-indigo-400" />
          ) : allPassed ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-400 animate-pulse" />
          )}

          <div>
            <div className="text-sm font-bold flex items-center gap-2">
              {!hasRunTests ? (
                <span>Test Inspector: Ready to test your code</span>
              ) : allPassed ? (
                <span>Awesome! All {totalCount} tests passed!</span>
              ) : (
                <span>
                  Fault Found: {totalCount - passingCount} of {totalCount} tests failing
                </span>
              )}
            </div>
            <div className="text-[11px] opacity-80">
              {!hasRunTests
                ? 'Click "Run & Test Code" to check your code against all challenge tests'
                : allPassed
                ? 'Your code matches all challenge requirements'
                : 'Read the instructions below to fix the fault in your code'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Prominent Run & Test button right in the inspector header */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRun();
            }}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow-md shadow-emerald-500/30 transition active:scale-95 cursor-pointer disabled:opacity-50 ring-2 ring-emerald-400/50"
            title="Run Code & Evaluate Tests"
          >
            <Play className={`w-3.5 h-3.5 fill-slate-950 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Testing...' : 'Run & Test Code'}</span>
          </button>

          {hasRunTests && allPassed && onNextLesson && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onNextLesson();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-bold shadow-md shadow-indigo-500/30 transition active:scale-95 cursor-pointer"
            >
              <span>Next Challenge</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          <button className="p-1 text-slate-400 hover:text-white transition">
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Inspector Body */}
      {isExpanded && (
        <div className="p-4 space-y-4 max-h-72 overflow-y-auto">
          {/* Big CTA when tests have not run yet */}
          {!hasRunTests && (
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-850 to-slate-850 border border-emerald-800/40 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-left">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                  Ready to test your challenge solution?
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  We will evaluate your HTML, CSS, and JS against all challenge rules.
                </div>
              </div>

              <button
                onClick={onRun}
                disabled={isRunning}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer disabled:opacity-50 shrink-0"
              >
                <Play className={`w-4 h-4 fill-slate-950 ${isRunning ? 'animate-spin' : ''}`} />
                <span>{isRunning ? 'Evaluating...' : 'Run & Test Code (Ctrl+Enter)'}</span>
              </button>
            </div>
          )}

          {/* Primary Fault Breakdown Card */}
          {hasRunTests && !allPassed && firstFault && (
            <div className="rounded-xl bg-rose-950/30 border border-rose-800/60 p-3.5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm">
                  <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>Fault Diagnosis: {firstFault.faultTitle || 'Syntax or Structural Mistake'}</span>
                </div>

                {/* AI Fault Doctor Button */}
                <button
                  onClick={onAskAiDoctor}
                  disabled={isLoadingAi}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition disabled:opacity-50 shrink-0"
                  title="Ask Gemini AI for a beginner-friendly diagnosis and analogy"
                >
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                  <span>{isLoadingAi ? 'Consulting AI...' : 'Ask AI Fault Doctor'}</span>
                </button>
              </div>

              {/* Specific fault message */}
              <div className="text-xs text-rose-200/90 bg-rose-950/40 p-2.5 rounded-lg border border-rose-900/50 font-mono">
                {firstFault.faultMessage}
              </div>

              {/* Beginner friendly explanation */}
              {firstFault.faultExplanation && (
                <div className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800 shadow-xs">
                  <div className="font-semibold text-rose-300 text-xs mb-1.5 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                    <span>Why this happened:</span>
                  </div>
                  <MarkdownRenderer
                    content={firstFault.faultExplanation}
                    variant="explanation"
                    className="text-slate-300"
                  />
                </div>
              )}

              {/* Actionable fix suggestion */}
              {firstFault.fixSuggestion && (
                <div className="text-xs text-emerald-300 bg-emerald-950/30 p-3 rounded-xl border border-emerald-900/50 flex items-start gap-2.5 shadow-xs">
                  <Lightbulb className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-emerald-200 text-xs mb-1">How to fix it:</div>
                    <MarkdownRenderer
                      content={firstFault.fixSuggestion}
                      variant="fix"
                      className="text-emerald-100/90"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Test Check Items */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Challenge Test Suite
            </div>
            {lesson.tests.map((test) => {
              const result = testResults.find((r) => r.id === test.id);
              const passed = result ? result.passed : false;

              return (
                <div
                  key={test.id}
                  className={`px-3 py-2 rounded-lg text-xs flex items-center justify-between border ${
                    !hasRunTests
                      ? 'bg-slate-800/40 border-slate-800 text-slate-400'
                      : passed
                      ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300'
                      : 'bg-rose-950/20 border-rose-900/40 text-rose-300 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    {!hasRunTests ? (
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-600 shrink-0" />
                    ) : passed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    )}
                    <span className="truncate">{test.description}</span>
                  </div>

                  {hasRunTests && !passed && (
                    <span className="text-[10px] text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded font-mono">
                      Fault
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Progressive Hints & Solution Disclosure */}
          <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                Hints:
              </span>
              {lesson.hints.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveHintIndex(activeHintIndex === i ? null : i)}
                  className={`px-2 py-1 rounded text-xs transition ${
                    activeHintIndex === i
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Hint {i + 1}
                </button>
              ))}
            </div>

            {/* Solution toggle */}
            <button
              onClick={() => setIsSolutionRevealed(!isSolutionRevealed)}
              className="text-xs text-slate-400 hover:text-slate-300 flex items-center gap-1 transition"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isSolutionRevealed ? 'Hide Solution' : 'Stuck? Reveal Solution'}</span>
            </button>
          </div>

          {/* Active Hint Content Card */}
          {activeHintIndex !== null && lesson.hints[activeHintIndex] && (
            <div className="bg-amber-950/30 border border-amber-800/50 rounded-xl p-3.5 text-xs text-amber-200 flex items-start gap-2.5 animate-fadeIn shadow-xs">
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-amber-300 text-xs mb-1.5 flex items-center gap-1.5">
                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px]">
                    Hint {activeHintIndex + 1} of {lesson.hints.length}
                  </span>
                </div>
                <MarkdownRenderer
                  content={lesson.hints[activeHintIndex]}
                  variant="hint"
                  className="text-amber-100/95"
                />
              </div>
            </div>
          )}

          {/* Revealed Solution Card */}
          {isSolutionRevealed && (
            <div className="bg-slate-950 border border-slate-700 rounded-lg p-3 space-y-2 text-xs animate-fadeIn">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-bold text-slate-200">Solution Reference</span>
                <span className="text-[10px] text-amber-400">Try to understand the logic before copying</span>
              </div>
              {lesson.solutionFiles.html && (
                <div>
                  <div className="text-[10px] text-orange-400 font-mono mb-0.5">HTML:</div>
                  <pre className="bg-slate-900 p-2 rounded text-slate-300 font-mono text-[11px] overflow-x-auto whitespace-pre-wrap">
                    {lesson.solutionFiles.html}
                  </pre>
                </div>
              )}
              {lesson.solutionFiles.css && (
                <div>
                  <div className="text-[10px] text-blue-400 font-mono mb-0.5">CSS:</div>
                  <pre className="bg-slate-900 p-2 rounded text-slate-300 font-mono text-[11px] overflow-x-auto whitespace-pre-wrap">
                    {lesson.solutionFiles.css}
                  </pre>
                </div>
              )}
              {lesson.solutionFiles.js && (
                <div>
                  <div className="text-[10px] text-yellow-400 font-mono mb-0.5">JavaScript:</div>
                  <pre className="bg-slate-900 p-2 rounded text-slate-300 font-mono text-[11px] overflow-x-auto whitespace-pre-wrap">
                    {lesson.solutionFiles.js}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
