import React from 'react';

interface MarkdownRendererProps {
  content: string;
  className?: string;
  variant?: 'default' | 'explanation' | 'hint' | 'fix';
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({
  content,
  className = '',
  variant = 'default',
}) => {
  if (!content) return null;

  // Helper to render inline markdown (code, bold, italic, tags)
  const renderInline = (text: string): React.ReactNode[] => {
    // Regular expressions for inline tokens
    // Split by inline code first: `code`
    const codeParts = text.split(/(`[^`]+`)/g);

    return codeParts.map((part, i) => {
      if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
        const codeText = part.slice(1, -1);
        const codeClasses =
          variant === 'explanation'
            ? 'px-1.5 py-0.5 rounded bg-rose-950/60 text-rose-300 font-mono text-[11px] border border-rose-800/60 select-all'
            : variant === 'hint'
            ? 'px-1.5 py-0.5 rounded bg-amber-950/60 text-amber-200 font-mono text-[11px] border border-amber-800/60 select-all'
            : variant === 'fix'
            ? 'px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-300 font-mono text-[11px] border border-emerald-800/60 select-all'
            : 'px-1.5 py-0.5 rounded bg-slate-800 text-indigo-300 font-mono text-[11px] border border-slate-700 select-all';

        return (
          <code key={`code-${i}`} className={codeClasses}>
            {codeText}
          </code>
        );
      }

      // Format bold, italic, and tags inside normal text
      return renderFormatting(part, i);
    });
  };

  const renderFormatting = (rawText: string, partIndex: number): React.ReactNode => {
    // Regex matching **bold**, *italic*, and <tag>
    const tokens = rawText.split(/(\*\*[^*]+\*\*|\*[^*]+\*|<[a-zA-Z0-9_\-]+[^>]*>)/g);

    return (
      <React.Fragment key={`fmt-${partIndex}`}>
        {tokens.map((token, j) => {
          if (token.startsWith('**') && token.endsWith('**') && token.length >= 4) {
            return (
              <strong key={`b-${j}`} className="font-bold text-white">
                {token.slice(2, -2)}
              </strong>
            );
          }
          if (token.startsWith('*') && token.endsWith('*') && token.length >= 2) {
            return (
              <em key={`em-${j}`} className="italic text-slate-200 font-medium">
                {token.slice(1, -1)}
              </em>
            );
          }
          if (token.startsWith('<') && token.endsWith('>') && !token.includes(' ')) {
            return (
              <span
                key={`tag-${j}`}
                className="font-mono text-[11px] text-indigo-300 bg-indigo-950/50 px-1 py-0.5 rounded border border-indigo-800/40"
              >
                {token}
              </span>
            );
          }
          return token;
        })}
      </React.Fragment>
    );
  };

  // Parse lines and blocks
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let inCodeBlock = false;
  let codeBlockLines: string[] = [];
  let currentListItems: string[] = [];
  let isNumberedList = false;

  const flushList = () => {
    if (currentListItems.length > 0) {
      const ListTag = isNumberedList ? 'ol' : 'ul';
      const listKey = `list-${elements.length}`;
      elements.push(
        <ListTag
          key={listKey}
          className={`space-y-1 my-1.5 ${
            isNumberedList ? 'list-decimal list-inside pl-1' : 'list-none pl-0'
          }`}
        >
          {currentListItems.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2 text-xs leading-relaxed text-slate-300">
              {!isNumberedList && (
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
              )}
              <span className="flex-1">{renderInline(item)}</span>
            </li>
          ))}
        </ListTag>
      );
      currentListItems = [];
    }
  };

  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx];

    // Check code fences ```
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        // End of code block
        elements.push(
          <pre
            key={`codeblock-${elements.length}`}
            className="my-2 p-2.5 rounded-lg bg-slate-950/90 border border-slate-800/80 font-mono text-[11px] text-emerald-300 overflow-x-auto whitespace-pre leading-relaxed shadow-inner"
          >
            <code>{codeBlockLines.join('\n')}</code>
          </pre>
        );
        codeBlockLines = [];
        inCodeBlock = false;
      } else {
        flushList();
        inCodeBlock = true;
      }
      continue;
    }

    if (inCodeBlock) {
      codeBlockLines.push(line);
      continue;
    }

    // Check bullet list item (- item or * item)
    const bulletMatch = line.match(/^[-*]\s+(.*)$/);
    if (bulletMatch) {
      if (isNumberedList) flushList();
      isNumberedList = false;
      currentListItems.push(bulletMatch[1]);
      continue;
    }

    // Check numbered list item (1. item)
    const numberMatch = line.match(/^\d+\.\s+(.*)$/);
    if (numberMatch) {
      if (!isNumberedList) flushList();
      isNumberedList = true;
      currentListItems.push(numberMatch[1]);
      continue;
    }

    // Normal line: flush pending list items
    flushList();

    // Check blockquote (> quote)
    const quoteMatch = line.match(/^>\s*(.*)$/);
    if (quoteMatch) {
      elements.push(
        <blockquote
          key={`quote-${idx}`}
          className="my-1.5 pl-3 border-l-2 border-indigo-400 text-slate-300 italic text-xs bg-slate-950/30 py-1 rounded-r"
        >
          {renderInline(quoteMatch[1])}
        </blockquote>
      );
      continue;
    }

    // Empty line creates visual breathing room
    if (!line.trim()) {
      elements.push(<div key={`empty-${idx}`} className="h-1.5" />);
      continue;
    }

    // Regular paragraph line
    elements.push(
      <p key={`p-${idx}`} className="leading-relaxed text-xs">
        {renderInline(line)}
      </p>
    );
  }

  flushList();

  return <div className={`space-y-1 font-sans ${className}`}>{elements}</div>;
};
