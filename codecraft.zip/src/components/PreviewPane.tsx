import React, { useState, useEffect, useRef } from 'react';
import { Monitor, Smartphone, Tablet, RefreshCw, Terminal, Eye, ExternalLink, Play } from 'lucide-react';
import { CodeFiles } from '../types';

interface PreviewPaneProps {
  files: CodeFiles;
  consoleLogs: string[];
  onClearConsole?: () => void;
  onRun?: () => void;
  isRunning?: boolean;
}

export const PreviewPane: React.FC<PreviewPaneProps> = ({
  files,
  consoleLogs,
  onClearConsole,
  onRun,
  isRunning,
}) => {
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState<'preview' | 'console'>('preview');
  const [key, setKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Generate complete HTML document bundle
  const bundledHtml = `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
          * { box-sizing: border-box; }
          body {
            margin: 0;
            padding: 16px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #ffffff;
            color: #0f172a;
          }
          ${files.css}
        </style>
      </head>
      <body>
        ${files.html}
        <script>
          // Capture iframe errors
          window.onerror = function(msg, url, line) {
            console.error('Runtime Error (line ' + line + '): ' + msg);
          };
          try {
            ${files.js}
          } catch(e) {
            console.error(e.message);
          }
        <\/script>
      </body>
    </html>
  `;

  const refreshPreview = () => {
    setKey((prev) => prev + 1);
  };

  const getContainerWidth = () => {
    switch (viewMode) {
      case 'mobile':
        return 'max-w-[375px]';
      case 'tablet':
        return 'max-w-[768px]';
      default:
        return 'w-full';
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-xl min-w-0">
      {/* Top Preview Toolbar */}
      <div className="h-11 bg-slate-900 border-b border-slate-800 px-3 flex items-center justify-between shrink-0 select-none">
        {/* View Tabs */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              activeTab === 'preview'
                ? 'bg-slate-800 text-indigo-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Live Output</span>
          </button>

          <button
            onClick={() => setActiveTab('console')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              activeTab === 'console'
                ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Console</span>
            {consoleLogs.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold flex items-center justify-center">
                {consoleLogs.length}
              </span>
            )}
          </button>
        </div>

        {/* Viewport size controls */}
        {activeTab === 'preview' && (
          <div className="hidden sm:flex items-center bg-slate-950/70 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setViewMode('desktop')}
              className={`p-1 rounded text-xs transition ${
                viewMode === 'desktop' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Desktop View (100%)"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('tablet')}
              className={`p-1 rounded text-xs transition ${
                viewMode === 'tablet' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Tablet View (768px)"
            >
              <Tablet className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('mobile')}
              className={`p-1 rounded text-xs transition ${
                viewMode === 'mobile' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Mobile View (375px)"
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Right actions */}
        <div className="flex items-center gap-1.5">
          {onRun && (
            <button
              onClick={onRun}
              disabled={isRunning}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition cursor-pointer disabled:opacity-50"
              title="Run Code & Test Solution"
            >
              <Play className={`w-3.5 h-3.5 fill-white ${isRunning ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">{isRunning ? 'Testing...' : 'Run & Test'}</span>
            </button>
          )}

          <button
            onClick={refreshPreview}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
            title="Reload Preview"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 bg-slate-900/40 relative flex items-center justify-center p-2 sm:p-4 overflow-auto">
        {activeTab === 'preview' ? (
          <div
            className={`h-full ${getContainerWidth()} bg-white rounded-lg overflow-hidden shadow-2xl transition-all duration-300 border border-slate-700/50 flex flex-col`}
          >
            {/* Browser top pill */}
            <div className="h-6 bg-slate-100 border-b border-slate-200 px-3 flex items-center gap-1.5 select-none shrink-0">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-[10px] text-slate-400 ml-2 font-mono truncate">
                localhost:3000/preview
              </span>
            </div>

            {/* Iframe */}
            <iframe
              key={key}
              ref={iframeRef}
              srcDoc={bundledHtml}
              sandbox="allow-scripts allow-modals allow-same-origin"
              title="Code Preview Sandbox"
              className="w-full flex-1 border-none bg-white"
            />
          </div>
        ) : (
          /* Virtual Console Output */
          <div className="w-full h-full bg-slate-950 rounded-lg border border-slate-800 p-4 font-mono text-xs flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span className="font-semibold text-slate-300">Browser Console Stream</span>
              </div>
              {onClearConsole && consoleLogs.length > 0 && (
                <button
                  onClick={onClearConsole}
                  className="text-[11px] text-slate-500 hover:text-slate-300 transition"
                >
                  Clear logs
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto pt-3 space-y-2 select-text">
              {consoleLogs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-600 space-y-2">
                  <Terminal className="w-8 h-8 text-slate-700" />
                  <p>No console messages logged yet.</p>
                  <p className="text-[11px] text-slate-700">
                    Use <code className="text-slate-500">console.log("hello")</code> in your code to see output!
                  </p>
                </div>
              ) : (
                consoleLogs.map((log, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-2.5 py-1 px-2 rounded bg-slate-900/60 border border-slate-800/80 text-slate-200"
                  >
                    <span className="text-slate-500 select-none text-[10px] pt-0.5">&gt;</span>
                    <span className="break-all whitespace-pre-wrap">{log}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
