import React, { useState, useRef } from 'react';
import { RotateCcw, Copy, Check, Play, Sparkles, AlertCircle, Wand2, Save } from 'lucide-react';
import { CodeFiles } from '../types';
import { checkLiveSyntax } from '../utils/liveLinter';

interface CodeEditorProps {
  files: CodeFiles;
  onChange: (files: CodeFiles) => void;
  onReset: () => void;
  onRun: () => void;
  isRunning: boolean;
  onSave?: () => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  files,
  onChange,
  onReset,
  onRun,
  isRunning,
  onSave,
}) => {
  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'js'>('html');
  const [copied, setCopied] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const currentCode = files[activeTab];
  const liveWarnings = checkLiveSyntax(activeTab, currentCode);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    onChange({
      ...files,
      [activeTab]: val,
    });
  };

  // Quick Snippet Insert Helper
  const handleInsertSnippet = (snippet: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const val = textarea.value;

    const newVal = val.substring(0, start) + snippet + val.substring(end);
    onChange({
      ...files,
      [activeTab]: newVal,
    });

    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + snippet.length;
    }, 0);
  };

  // Enable Tab key indentation & shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      onRun();
      return;
    }

    if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
      e.preventDefault();
      onSave?.();
      return;
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = textareaRef.current;
      if (!textarea) return;

      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const val = textarea.value;

      const newVal = val.substring(0, start) + '  ' + val.substring(end);
      onChange({
        ...files,
        [activeTab]: newVal,
      });

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      }, 0);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(files[activeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lineCount = Math.max(1, currentCode.split('\n').length);
  const linesArray = Array.from({ length: lineCount }, (_, i) => i + 1);

  // Quick Snippet definitions per language
  const htmlSnippets = ['<h1>', '<p>', '<a href="">', '<img src="" alt="">', '<ul>', '<li>', '<button>'];
  const cssSnippets = ['display: flex;', 'justify-content: center;', 'padding: 16px;', 'border: 2px solid;', 'border-radius: 8px;'];
  const jsSnippets = ['const ', 'let ', 'function name() {}', 'console.log()', 'document.getElementById()'];

  const activeSnippets = activeTab === 'html' ? htmlSnippets : activeTab === 'css' ? cssSnippets : jsSnippets;

  return (
    <div className="flex-1 flex flex-col bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-xl min-w-0">
      {/* Top Editor Toolbar */}
      <div className="h-11 bg-slate-900 border-b border-slate-800 px-3 flex items-center justify-between shrink-0 select-none">
        {/* File Tabs */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('html')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              activeTab === 'html'
                ? 'bg-slate-800 text-orange-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-orange-500" />
            <span>index.html</span>
          </button>

          <button
            onClick={() => setActiveTab('css')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              activeTab === 'css'
                ? 'bg-slate-800 text-blue-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            <span>styles.css</span>
          </button>

          <button
            onClick={() => setActiveTab('js')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              activeTab === 'js'
                ? 'bg-slate-800 text-yellow-400 border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-yellow-500" />
            <span>script.js</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5">
          {onSave && (
            <button
              onClick={onSave}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition flex items-center gap-1 cursor-pointer"
              title="Save Progress Manually (Ctrl+S)"
            >
              <Save className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline text-[10px] text-slate-400 font-mono">Ctrl+S</span>
            </button>
          )}

          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
            title="Copy Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => {
              if (window.confirm('Reset this lesson back to original starter code?')) {
                onReset();
              }
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
            title="Reset to Starter Code"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onRun}
            disabled={isRunning}
            className="flex items-center gap-1.5 ml-2 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/30 ring-2 ring-emerald-400/50 disabled:opacity-50 transition active:scale-95 cursor-pointer"
            title="Run Code and Run Tests (Ctrl+Enter)"
          >
            <Play className={`w-3.5 h-3.5 fill-slate-950 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Evaluating...' : 'Run & Test Code'}</span>
            <span className="hidden sm:inline text-[10px] opacity-75 font-mono ml-0.5 bg-black/15 px-1 py-0.2 rounded">Ctrl+↵</span>
          </button>
        </div>
      </div>

      {/* Quick Snippets Insertion Helper Bar */}
      <div className="h-7 bg-slate-900/60 border-b border-slate-800/80 px-2 flex items-center gap-1.5 overflow-x-auto text-[11px] text-slate-400 shrink-0 select-none">
        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider pl-1 flex items-center gap-1">
          <Wand2 className="w-3 h-3 text-indigo-400" /> Insert:
        </span>
        {activeSnippets.map((snip, idx) => (
          <button
            key={idx}
            onClick={() => handleInsertSnippet(snip)}
            className="px-2 py-0.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono text-[10px] transition shrink-0"
            title={`Click to insert ${snip} at cursor`}
          >
            {snip}
          </button>
        ))}
      </div>

      {/* Editor Body with Line Numbers & Textarea */}
      <div className="flex-1 relative flex overflow-hidden font-mono text-sm leading-6">
        {/* Line Numbers Gutter */}
        <div className="w-12 bg-slate-900/60 border-r border-slate-800/80 py-4 select-none text-right pr-3 text-slate-600 shrink-0 text-xs overflow-hidden">
          {linesArray.map((line) => (
            <div key={line} className="h-6">
              {line}
            </div>
          ))}
        </div>

        {/* Textarea Input */}
        <textarea
          ref={textareaRef}
          value={currentCode}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          autoCorrect="off"
          className="flex-1 h-full p-4 bg-transparent text-slate-100 placeholder-slate-600 focus:outline-none resize-none font-mono text-xs sm:text-sm leading-6 overflow-y-auto selection:bg-indigo-500/30 whitespace-pre"
          placeholder={`Write your ${activeTab.toUpperCase()} code here...`}
        />
      </div>

      {/* Real-time Live Fault Notice (if warning detected) */}
      {liveWarnings.length > 0 && (
        <div className="bg-amber-950/40 border-t border-amber-800/60 px-3 py-1.5 text-xs text-amber-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 truncate">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{liveWarnings[0].message}</span>
          </div>
          {liveWarnings[0].suggestedFix && (
            <span className="text-[10px] font-semibold text-emerald-300 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50 shrink-0 ml-2">
              Tip: {liveWarnings[0].suggestedFix}
            </span>
          )}
        </div>
      )}

      {/* Editor Bottom Bar */}
      <div className="h-7 bg-slate-900 border-t border-slate-800 px-3 flex items-center justify-between text-[11px] text-slate-500 select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span>Tab: 2 Spaces</span>
          <span>Lines: {lineCount}</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Real-Time Fault Inspector Active</span>
        </div>
      </div>
    </div>
  );
};
