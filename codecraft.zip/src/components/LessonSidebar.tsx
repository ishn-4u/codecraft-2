import React from 'react';
import { CheckCircle2, Lock, Sparkles, BookOpen, Clock, X, ChevronRight, Trophy } from 'lucide-react';
import { Lesson, TrackId, StreakData } from '../types';
import { LESSONS, TRACK_METADATA } from '../data/curriculum';

interface LessonSidebarProps {
  currentLessonId: string;
  onSelectLesson: (lessonId: string) => void;
  streakData: StreakData;
  isOpen: boolean;
  onClose: () => void;
}

export const LessonSidebar: React.FC<LessonSidebarProps> = ({
  currentLessonId,
  onSelectLesson,
  streakData,
  isOpen,
  onClose,
}) => {
  const tracks: TrackId[] = ['html', 'css', 'javascript', 'frontend', 'backend'];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:static top-0 left-0 h-full w-80 bg-slate-900 border-r border-slate-800 flex flex-col z-40 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              Learning Roadmap
              <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                Alt+L
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">Zero to Full-Stack Developer</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Curriculum Tree */}
        <div className="flex-1 overflow-y-auto p-3 space-y-6">
          {tracks.map((trackId, trackIndex) => {
            const trackMeta = TRACK_METADATA[trackId];
            const trackLessons = LESSONS.filter((l) => l.trackId === trackId);
            const completedCount = trackLessons.filter((l) =>
              streakData.completedLessonIds.includes(l.id)
            ).length;
            const progressPercent = Math.round((completedCount / trackLessons.length) * 100);
            const isCompleted = completedCount === trackLessons.length && trackLessons.length > 0;

            return (
              <div key={trackId} className="space-y-2">
                {/* Track Header Card */}
                <div className="px-3 py-2 rounded-xl bg-slate-800/40 border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      {trackMeta.title}
                    </span>
                    {isCompleted ? (
                      <span className="text-[10px] font-semibold text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                        <Trophy className="w-3 h-3" /> Complete
                      </span>
                    ) : (
                      <span className="text-[11px] font-medium text-slate-400">
                        {completedCount}/{trackLessons.length}
                      </span>
                    )}
                  </div>

                  {/* Progress mini bar */}
                  <div className="w-full h-1.5 bg-slate-700/60 rounded-full mt-2 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 rounded-full bg-gradient-to-r ${trackMeta.color}`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Lesson List */}
                <div className="space-y-1 pl-1">
                  {trackLessons.map((lesson) => {
                    const isSelected = lesson.id === currentLessonId;
                    const isDone = streakData.completedLessonIds.includes(lesson.id);
                    const isProject = lesson.category === 'project';

                    return (
                      <button
                        key={lesson.id}
                        id={isSelected ? 'active-lesson-btn' : undefined}
                        onClick={() => {
                          onSelectLesson(lesson.id);
                          onClose();
                        }}
                        className={`w-full text-left px-3 py-2.5 rounded-xl text-xs flex items-center gap-3 transition group relative focus:outline-none focus:ring-2 focus:ring-indigo-400 ${
                          isSelected
                            ? 'bg-indigo-600 text-white font-semibold shadow-lg shadow-indigo-600/30 ring-1 ring-indigo-400'
                            : isDone
                            ? 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white'
                            : 'bg-transparent text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                        }`}
                      >
                        {/* Status Icon */}
                        <div className="shrink-0">
                          {isDone ? (
                            <CheckCircle2
                              className={`w-4 h-4 ${
                                isSelected ? 'text-emerald-200' : 'text-emerald-400'
                              }`}
                            />
                          ) : isProject ? (
                            <Sparkles
                              className={`w-4 h-4 ${
                                isSelected ? 'text-amber-200' : 'text-amber-400'
                              }`}
                            />
                          ) : (
                            <div
                              className={`w-2 h-2 rounded-full mx-1 ${
                                isSelected ? 'bg-white' : 'bg-slate-600 group-hover:bg-slate-400'
                              }`}
                            />
                          )}
                        </div>

                        {/* Title & Info */}
                        <div className="flex-1 min-w-0">
                          <div className="truncate text-[13px] leading-tight flex items-center gap-1.5">
                            <span className="truncate">{lesson.title}</span>
                            {isProject && (
                              <span
                                className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                                  isSelected
                                    ? 'bg-white/20 text-white'
                                    : 'bg-amber-400/20 text-amber-300'
                                }`}
                              >
                                Project
                              </span>
                            )}
                          </div>
                          <div
                            className={`flex items-center gap-2 mt-1 text-[11px] ${
                              isSelected ? 'text-indigo-200' : 'text-slate-500'
                            }`}
                          >
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {lesson.estimatedTime}
                            </span>
                            <span>•</span>
                            <span>+{lesson.xpReward} XP</span>
                          </div>
                        </div>

                        {/* Arrow */}
                        <ChevronRight
                          className={`w-3.5 h-3.5 shrink-0 transition-transform ${
                            isSelected ? 'translate-x-0.5 text-white' : 'opacity-0 group-hover:opacity-100 text-slate-500'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Streak summary */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/90 text-xs text-slate-400 flex items-center justify-between">
          <span>{streakData.completedLessonIds.length} of {LESSONS.length} completed</span>
          <span className="font-semibold text-slate-300">
            {Math.round((streakData.completedLessonIds.length / LESSONS.length) * 100)}% Complete
          </span>
        </div>
      </aside>
    </>
  );
};
