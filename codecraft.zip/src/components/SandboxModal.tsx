import React, { useState } from 'react';
import { X, Download, Sparkles, RefreshCw, LayoutTemplate } from 'lucide-react';
import { CodeFiles } from '../types';

interface SandboxModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TEMPLATES: Record<string, { title: string; files: CodeFiles }> = {
  glassmorphism: {
    title: 'Glassmorphism Card',
    files: {
      html: `<div class="hero">\n  <h1>✨ My Playground Creation</h1>\n  <p>Type any HTML, CSS, and JS here to experiment without limits!</p>\n  <button id="alertBtn">Click Me</button>\n</div>`,
      css: `body {\n  font-family: system-ui, sans-serif;\n  background: linear-gradient(135deg, #1e1b4b, #0f172a);\n  color: white;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  min-height: 90vh;\n  margin: 0;\n}\n.hero {\n  background: rgba(255, 255, 255, 0.05);\n  backdrop-filter: blur(10px);\n  padding: 32px;\n  border-radius: 20px;\n  border: 1px solid rgba(255, 255, 255, 0.1);\n  text-align: center;\n  max-width: 440px;\n}\nh1 {\n  font-size: 24px;\n  margin-bottom: 8px;\n  color: #38bdf8;\n}\np {\n  color: #94a3b8;\n  font-size: 14px;\n  line-height: 1.6;\n}\nbutton {\n  background: #38bdf8;\n  color: #0f172a;\n  font-weight: 700;\n  border: none;\n  padding: 10px 24px;\n  border-radius: 10px;\n  cursor: pointer;\n  margin-top: 16px;\n  transition: transform 0.1s;\n}\nbutton:active {\n  transform: scale(0.96);\n}`,
      js: `const btn = document.getElementById("alertBtn");\nbtn.addEventListener("click", () => {\n  const colors = ["#f43f5e", "#8b5cf6", "#10b981", "#f59e0b", "#06b6d4"];\n  const randomColor = colors[Math.floor(Math.random() * colors.length)];\n  btn.style.backgroundColor = randomColor;\n  console.log("Button clicked! Color set to: " + randomColor);\n});`,
    },
  },
  counter: {
    title: 'Interactive Counter',
    files: {
      html: `<div style="text-align: center; padding: 40px; font-family: system-ui;">\n  <h1>Interactive Counter</h1>\n  <div id="counter" style="font-size: 64px; font-weight: 900; color: #4f46e5; margin: 20px 0;">0</div>\n  <div style="display: flex; gap: 12px; justify-content: center;">\n    <button id="decBtn" style="padding: 12px 24px; font-size: 18px; border-radius: 8px; border: 1px solid #ccc; cursor: pointer;">- 1</button>\n    <button id="resetBtn" style="padding: 12px 24px; font-size: 18px; border-radius: 8px; border: 1px solid #ccc; cursor: pointer;">Reset</button>\n    <button id="incBtn" style="padding: 12px 24px; font-size: 18px; border-radius: 8px; background: #4f46e5; color: white; border: none; cursor: pointer;">+ 1</button>\n  </div>\n</div>`,
      css: `body { margin: 0; background: #f8fafc; } button:active { transform: scale(0.95); }`,
      js: `let count = 0;\nconst display = document.getElementById("counter");\ndocument.getElementById("incBtn").onclick = () => { count++; display.textContent = count; };\ndocument.getElementById("decBtn").onclick = () => { count--; display.textContent = count; };\ndocument.getElementById("resetBtn").onclick = () => { count = 0; display.textContent = count; };`,
    },
  },
  clock: {
    title: 'Live Digital Clock',
    files: {
      html: `<div class="clock-card">\n  <div class="label">LIVE BROWSER TIME</div>\n  <div id="time">00:00:00</div>\n  <div id="date">Loading...</div>\n</div>`,
      css: `body { background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; min-height: 90vh; font-family: monospace; }\n.clock-card { background: #1e293b; padding: 40px; border-radius: 20px; text-align: center; border: 1px solid #334155; }\n.label { color: #38bdf8; font-size: 12px; letter-spacing: 2px; margin-bottom: 12px; }\n#time { font-size: 54px; font-weight: bold; color: #f8fafc; }\n#date { color: #94a3b8; font-size: 14px; margin-top: 10px; font-family: sans-serif; }`,
      js: `function updateClock() {\n  const now = new Date();\n  document.getElementById("time").textContent = now.toLocaleTimeString();\n  document.getElementById("date").textContent = now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });\n}\nsetInterval(updateClock, 1000);\nupdateClock();`,
    },
  },
};

export const SandboxModal: React.FC<SandboxModalProps> = ({ isOpen, onClose }) => {
  const [files, setFiles] = useState<CodeFiles>(TEMPLATES.glassmorphism.files);
  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'js'>('html');
  const [key, setKey] = useState(0);

  if (!isOpen) return null;

  const bundledHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <style>${files.css}</style>
      </head>
      <body>
        ${files.html}
        <script>
          try {
            ${files.js}
          } catch(e) {
            console.error(e);
          }
        <\/script>
      </body>
    </html>
  `;

  const downloadProject = () => {
    const blob = new Blob([bundledHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'codecraft-project.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const loadTemplate = (keyName: string) => {
    if (TEMPLATES[keyName]) {
      setFiles(TEMPLATES[keyName].files);
      setKey((k) => k + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      {/* Top Bar */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-bold text-white">Free-Form Coding Playground</h2>
          </div>

          <div className="hidden sm:flex items-center gap-1 pl-4 border-l border-slate-800 text-xs text-slate-400">
            <LayoutTemplate className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[11px] font-semibold text-slate-500 uppercase mr-1">Templates:</span>
            {Object.entries(TEMPLATES).map(([k, t]) => (
              <button
                key={k}
                onClick={() => loadTemplate(k)}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
              >
                {t.title}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setKey((k) => k + 1)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Rerun</span>
          </button>

          <button
            onClick={downloadProject}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-md shadow-indigo-600/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export HTML File</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Sandbox Grid */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Editor Half */}
        <div className="flex-1 flex flex-col border-b md:border-b-0 md:border-r border-slate-800 bg-slate-950">
          <div className="h-10 bg-slate-900/80 border-b border-slate-800 px-3 flex items-center gap-2">
            <button
              onClick={() => setActiveTab('html')}
              className={`px-3 py-1 rounded-md text-xs font-semibold ${
                activeTab === 'html' ? 'bg-slate-800 text-orange-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              index.html
            </button>
            <button
              onClick={() => setActiveTab('css')}
              className={`px-3 py-1 rounded-md text-xs font-semibold ${
                activeTab === 'css' ? 'bg-slate-800 text-blue-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              styles.css
            </button>
            <button
              onClick={() => setActiveTab('js')}
              className={`px-3 py-1 rounded-md text-xs font-semibold ${
                activeTab === 'js' ? 'bg-slate-800 text-yellow-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              script.js
            </button>
          </div>

          <textarea
            value={files[activeTab]}
            onChange={(e) => setFiles({ ...files, [activeTab]: e.target.value })}
            className="flex-1 p-4 bg-transparent text-slate-100 font-mono text-xs sm:text-sm resize-none focus:outline-none leading-relaxed"
            spellCheck={false}
          />
        </div>

        {/* Live Preview Half */}
        <div className="flex-1 bg-slate-900 flex flex-col">
          <div className="h-10 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Live Interactive Preview</span>
            <span>Unrestricted Sandbox</span>
          </div>

          <div className="flex-1 bg-white">
            <iframe
              key={key}
              srcDoc={bundledHtml}
              sandbox="allow-scripts allow-modals allow-same-origin"
              className="w-full h-full border-none"
              title="Sandbox Output"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
