import React, { useState } from 'react';
import { BookOpen, Sparkles, AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Clock, Target, Play } from 'lucide-react';
import { Lesson } from '../types';

interface LessonGuideProps {
  lesson: Lesson;
  onRun?: () => void;
  isRunning?: boolean;
}

export const LessonGuide: React.FC<LessonGuideProps> = ({ lesson, onRun, isRunning }) => {
  const [showMistakes, setShowMistakes] = useState(true);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 space-y-5 text-slate-200 shadow-xl overflow-y-auto max-h-[50vh] lg:max-h-none">
      {/* Lesson Header */}
      <div className="space-y-1.5 border-b border-slate-800 pb-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
            {lesson.trackTitle}
          </span>
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {lesson.estimatedTime}
          </span>
          <span className="text-[11px] font-medium text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
            +{lesson.xpReward} XP
          </span>
        </div>

        <h1 className="text-lg sm:text-xl font-black text-white tracking-tight">
          {lesson.title}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">{lesson.subtitle}</p>
      </div>

      {/* Concept Explanation (Markdown-like formatted text) */}
      <div className="text-xs sm:text-sm leading-relaxed text-slate-300 space-y-2 whitespace-pre-wrap font-sans">
        {lesson.conceptExplanation}
      </div>

      {/* Zero-Knowledge Beginner Tips */}
      {lesson.zeroKnowledgeTips.length > 0 && (
        <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-800/40 space-y-2">
          <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            Zero-Knowledge Mental Model
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300 pl-4 list-disc marker:text-indigo-400">
            {lesson.zeroKnowledgeTips.map((tip, idx) => (
              <li key={idx} className="leading-normal">{tip}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Common Beginner Mistakes */}
      {lesson.commonMistakes.length > 0 && (
        <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-800/40 space-y-2.5">
          <button
            onClick={() => setShowMistakes(!showMistakes)}
            className="w-full flex items-center justify-between text-xs font-bold text-amber-300"
          >
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              Common Beginner Faults & How to Avoid Them
            </div>
            {showMistakes ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showMistakes && (
            <div className="space-y-2 pt-1 text-xs">
              {lesson.commonMistakes.map((m, idx) => (
                <div key={idx} className="p-2.5 rounded-lg bg-slate-900/80 border border-amber-900/30 space-y-1">
                  <div className="font-semibold text-rose-300 font-mono text-[11px]">
                    ⚠️ Mistake: {m.mistake}
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    <span className="text-slate-300 font-medium">Why it fails: </span>{m.why}
                  </div>
                  <div className="text-emerald-400 font-medium text-[11px]">
                    ✓ Solution: {m.solution}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Instructions Checklist */}
      <div className="space-y-2 pt-2 border-t border-slate-800">
        <div className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <Target className="w-4 h-4 text-emerald-400" />
          Your Tasks For This Challenge
        </div>
        <div className="space-y-1.5 pl-1">
          {lesson.instructions.map((inst, idx) => (
            <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
              <span className="w-4 h-4 rounded-full bg-slate-800 border border-slate-700 text-slate-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <span className="leading-snug">{inst}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Target Goal Summary */}
      <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs text-slate-300 flex items-center gap-2">
        <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
        <span>
          <strong className="text-white">Goal:</strong> {lesson.expectedGoal}
        </span>
      </div>

      {/* Prominent Run & Test Button */}
      {onRun && (
        <button
          onClick={onRun}
          disabled={isRunning}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer disabled:opacity-50 ring-2 ring-emerald-400/30"
          title="Run Code & Test Solution"
        >
          <Play className={`w-4 h-4 fill-white ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? 'Evaluating Tests...' : 'Run & Test Code'}</span>
          <span className="text-[11px] opacity-80 font-mono ml-1 bg-black/25 px-2 py-0.5 rounded">Ctrl+↵</span>
        </button>
      )}
    </div>
  );
};
