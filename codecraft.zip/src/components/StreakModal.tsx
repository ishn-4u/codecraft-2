import React from 'react';
import { Flame, Shield, Award, CheckCircle, Calendar, Sparkles, X, Trophy } from 'lucide-react';
import { StreakData } from '../types';
import { ALL_BADGES, calculateLevel } from '../utils/streakManager';

interface StreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  streakData: StreakData;
}

export const StreakModal: React.FC<StreakModalProps> = ({
  isOpen,
  onClose,
  streakData,
}) => {
  if (!isOpen) return null;

  const levelInfo = calculateLevel(streakData.totalXp);

  // Generate calendar days for current month
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = now.toLocaleString('default', { month: 'long' });

  const daysArray = Array.from({ length: daysInMonth }, (_, i) => {
    const dayNum = i + 1;
    const formatted = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    const isActive = streakData.activeDates.includes(formatted);
    const isToday = dayNum === now.getDate();
    return { dayNum, formatted, isActive, isToday };
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-scaleUp">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <Flame className="w-5 h-5 text-amber-500 fill-amber-500 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Daily Coding Streak
              </h3>
              <p className="text-xs text-slate-400">Consistency is the secret to mastering code</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Top Streak Stats Grid */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-center">
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Current Streak</div>
              <div className="text-2xl font-black text-amber-400 mt-1 flex items-center justify-center gap-1">
                <Flame className="w-5 h-5 fill-amber-400" />
                {streakData.currentStreak}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Days in a row</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-center">
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Record Streak</div>
              <div className="text-2xl font-black text-indigo-400 mt-1 flex items-center justify-center gap-1">
                <Trophy className="w-5 h-5 text-indigo-400" />
                {streakData.highestStreak}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Best record</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-center">
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Streak Freezes</div>
              <div className="text-2xl font-black text-cyan-400 mt-1 flex items-center justify-center gap-1">
                <Shield className="w-5 h-5 text-cyan-400" />
                {streakData.streakFreezes}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Safety shields</div>
            </div>
          </div>

          {/* Level Progress */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-indigo-950/40 to-slate-800/60 border border-indigo-900/40 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-indigo-300">
                Level {levelInfo.level}: {levelInfo.title}
              </span>
              <span className="text-slate-400">
                {levelInfo.currentLevelXp} / {levelInfo.nextLevelXp} XP to next level
              </span>
            </div>
            <div className="w-full h-2 bg-slate-700/60 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
                style={{ width: `${levelInfo.progressPercent}%` }}
              />
            </div>
          </div>

          {/* Monthly Activity Calendar */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-indigo-400" />
                {monthName} {year} Activity
              </span>
              <span className="text-[11px] text-amber-400 font-medium">
                {streakData.activeDates.length} Days Active
              </span>
            </div>

            <div className="grid grid-cols-7 gap-1.5 text-center">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                <div key={i} className="text-[10px] font-semibold text-slate-500 py-0.5">
                  {day}
                </div>
              ))}
              {daysArray.map((d) => (
                <div
                  key={d.dayNum}
                  className={`h-7 rounded-lg flex items-center justify-center text-xs font-semibold transition ${
                    d.isActive
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs'
                      : d.isToday
                      ? 'bg-slate-800 text-white ring-1 ring-indigo-400'
                      : 'text-slate-600 bg-slate-900/40'
                  }`}
                  title={`${d.formatted}: ${d.isActive ? 'Completed Challenge!' : 'No activity'}`}
                >
                  {d.isActive ? '🔥' : d.dayNum}
                </div>
              ))}
            </div>
          </div>

          {/* Badges Showcase */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-yellow-400" />
                Your Badges & Achievements
              </span>
              <span className="text-slate-500 text-[11px]">
                {streakData.earnedBadges.length} of {ALL_BADGES.length} unlocked
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {ALL_BADGES.map((b) => {
                const unlocked = streakData.earnedBadges.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition ${
                      unlocked
                        ? 'bg-slate-800/70 border-amber-500/30 text-slate-200'
                        : 'bg-slate-950/40 border-slate-800/80 text-slate-500 opacity-60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-sm ${
                        unlocked ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-600'
                      }`}
                    >
                      {unlocked ? '🏆' : '🔒'}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate text-slate-200">{b.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{b.requirement}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
