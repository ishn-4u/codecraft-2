import React from 'react';
import { X, Cloud, AlertCircle, RefreshCw, ExternalLink, ShieldCheck, CheckCircle2, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { user, isSigningIn, authError, clearAuthError, signInWithGoogle, signOut } = useAuth();

  if (!isOpen) return null;

  const handlePopupSignIn = async () => {
    await signInWithGoogle(false);
  };

  const handleRedirectSignIn = async () => {
    await signInWithGoogle(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
              <Cloud className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {user ? 'Account & Cloud Sync' : 'Sign In to CodeCraft'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {user ? 'Your progress is backed up to Firestore' : 'Sync your streak and code across devices'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              clearAuthError();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {user ? (
            /* Logged in state */
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-12 h-12 rounded-xl object-cover ring-2 ring-emerald-500/50"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-lg font-bold text-white">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-bold text-white truncate">{user.displayName || 'Coder'}</div>
                  <div className="text-xs text-slate-400 truncate">{user.email}</div>
                  <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Cloud Sync Active</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-300 space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                <div className="text-slate-400 font-medium">Automatic Cloud Features:</div>
                <div className="flex items-center gap-2 text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Real-time code persistence on every test run</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Daily streak tracking and freeze preservation</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>XP levels and unlocked skill achievements</span>
                </div>
              </div>

              <button
                onClick={async () => {
                  await signOut();
                  onClose();
                }}
                className="w-full py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 border border-rose-800/60 text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of Account</span>
              </button>
            </div>
          ) : (
            /* Logged out state */
            <div className="space-y-4">
              {/* Error Banner */}
              {authError && (
                <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-800/70 text-rose-200 text-xs space-y-2">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div className="leading-snug">
                      <span className="font-bold text-rose-300">Sign-In Notice: </span>
                      {authError}
                    </div>
                  </div>

                  {/* Actions for common browser popup blockage */}
                  <div className="pt-2 border-t border-rose-900/60 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={handleRedirectSignIn}
                      disabled={isSigningIn}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] transition text-center cursor-pointer disabled:opacity-50"
                    >
                      Try Direct Redirect Sign-In
                    </button>
                    <a
                      href={window.location.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-[11px] transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Open in Full Tab</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              )}

              {/* Main Google Sign In Button */}
              <button
                onClick={handlePopupSignIn}
                disabled={isSigningIn}
                className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-black text-sm shadow-xl flex items-center justify-center gap-3 transition active:scale-98 cursor-pointer disabled:opacity-75"
              >
                {isSigningIn ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-900" />
                    <span>Connecting to Google...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                      />
                    </svg>
                    <span>Continue with Google</span>
                  </>
                )}
              </button>

              {/* What You Get Highlights */}
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2 text-xs">
                <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Cloud Sync Benefits</span>
                </div>
                <ul className="text-slate-400 space-y-1 pl-1 text-[11px]">
                  <li>• Seamlessly switch between phone, laptop, and desktop</li>
                  <li>• Never lose your written solution code</li>
                  <li>• Preserve consecutive streak days with automatic backups</li>
                </ul>
              </div>

              {/* Troubleshooting hint */}
              <div className="text-[11px] text-slate-400 text-center leading-relaxed">
                If your browser blocks the pop-up, click the pop-up icon in your address bar to allow pop-ups for this site, or use direct redirect.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
