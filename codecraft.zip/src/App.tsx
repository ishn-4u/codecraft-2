import React, { useState, useEffect, useCallback } from 'react';
import { Play, CheckCircle2 } from 'lucide-react';
import { Header } from './components/Header';
import { LessonSidebar } from './components/LessonSidebar';
import { LessonGuide } from './components/LessonGuide';
import { CodeEditor } from './components/CodeEditor';
import { PreviewPane } from './components/PreviewPane';
import { FaultInspector } from './components/FaultInspector';
import { StreakModal } from './components/StreakModal';
import { AiDoctorModal } from './components/AiDoctorModal';
import { SuccessModal } from './components/SuccessModal';
import { GlossaryModal } from './components/GlossaryModal';
import { SandboxModal } from './components/SandboxModal';
import { RoadmapModal } from './components/RoadmapModal';
import { AuthModal } from './components/AuthModal';

import { CodeFiles, Lesson, TestResult, TrackId, FaultAnalysisResult, Badge } from './types';
import { LESSONS, TRACK_METADATA } from './data/curriculum';
import { runLessonTests } from './utils/testRunner';
import { triggerConfetti } from './utils/confetti';
import { loadStreakData, recordChallengeCompleted } from './utils/streakManager';
import { playSuccessChime, playFaultAlert } from './utils/soundEffects';
import { useAuth } from './context/AuthContext';

export default function App() {
  const { user, authError, syncProgressToCloud, loadProgressFromCloud } = useAuth();
  const [streakData, setStreakData] = useState(() => loadStreakData());
  const [isMuted, setIsMuted] = useState(() => localStorage.getItem('codecraft_muted') === 'true');
  const [currentLessonId, setCurrentLessonId] = useState<string>(() => {
    const saved = localStorage.getItem('codecraft_current_lesson');
    return saved && LESSONS.some((l) => l.id === saved) ? saved : LESSONS[0].id;
  });

  // Track code state per lesson
  const [codeFiles, setCodeFiles] = useState<CodeFiles>(() => {
    const activeLesson = LESSONS.find((l) => l.id === currentLessonId) || LESSONS[0];
    const savedCode = localStorage.getItem(`codecraft_code_${activeLesson.id}`);
    if (savedCode) {
      try {
        return JSON.parse(savedCode);
      } catch (e) {
        console.error(e);
      }
    }
    return { ...activeLesson.initialFiles };
  });

  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [allPassed, setAllPassed] = useState(false);
  const [hasRunTests, setHasRunTests] = useState(false);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Modals
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isStreakModalOpen, setIsStreakModalOpen] = useState(false);
  const [isGlossaryModalOpen, setIsGlossaryModalOpen] = useState(false);
  const [isSandboxModalOpen, setIsSandboxModalOpen] = useState(false);
  const [isRoadmapModalOpen, setIsRoadmapModalOpen] = useState(false);
  const [isAiDoctorModalOpen, setIsAiDoctorModalOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // AI Doctor State
  const [aiDoctorResult, setAiDoctorResult] = useState<FaultAnalysisResult | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [newlyEarnedBadges, setNewlyEarnedBadges] = useState<Badge[]>([]);

  const currentLesson = LESSONS.find((l) => l.id === currentLessonId) || LESSONS[0];

  const toggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      localStorage.setItem('codecraft_muted', String(next));
      return next;
    });
  };

  // Save current lesson ID and code changes
  useEffect(() => {
    localStorage.setItem('codecraft_current_lesson', currentLessonId);
  }, [currentLessonId]);

  useEffect(() => {
    localStorage.setItem(`codecraft_code_${currentLesson.id}`, JSON.stringify(codeFiles));
  }, [codeFiles, currentLesson.id]);

  // Sync with Firestore Cloud when user signs in
  useEffect(() => {
    if (user) {
      loadProgressFromCloud().then((cloudData) => {
        if (cloudData) {
          if (cloudData.streak) {
            setStreakData(cloudData.streak);
          }
          if (cloudData.codeMap && cloudData.codeMap[currentLessonId]) {
            setCodeFiles(cloudData.codeMap[currentLessonId]);
          }
        }
      });
    }
  }, [user]);

  // Open modal if authentication error occurs so user gets clear guidance
  useEffect(() => {
    if (authError) {
      setIsAuthModalOpen(true);
    }
  }, [authError]);

  // Load new lesson code when switching lesson
  const handleSelectLesson = (lessonId: string) => {
    const nextLesson = LESSONS.find((l) => l.id === lessonId);
    if (!nextLesson) return;

    setCurrentLessonId(lessonId);
    const saved = localStorage.getItem(`codecraft_code_${lessonId}`);
    if (saved) {
      try {
        setCodeFiles(JSON.parse(saved));
      } catch {
        setCodeFiles({ ...nextLesson.initialFiles });
      }
    } else {
      setCodeFiles({ ...nextLesson.initialFiles });
    }

    setTestResults([]);
    setAllPassed(false);
    setHasRunTests(false);
    setConsoleLogs([]);
  };

  // Reset to original starter files
  const handleResetCode = () => {
    setCodeFiles({ ...currentLesson.initialFiles });
    setTestResults([]);
    setAllPassed(false);
    setHasRunTests(false);
    setConsoleLogs([]);
    localStorage.removeItem(`codecraft_code_${currentLesson.id}`);
  };

  // Run Test Suite & Diagnostics
  const handleRunCode = useCallback(async () => {
    setIsRunningTests(true);
    try {
      const { results, allPassed: passed, consoleLogs: logs } = await runLessonTests(
        currentLesson,
        codeFiles
      );

      setTestResults(results);
      setAllPassed(passed);
      setHasRunTests(true);
      setConsoleLogs(logs);

      if (passed) {
        playSuccessChime(isMuted);
        triggerConfetti();
        const { data: updatedStreak, newlyEarnedBadges: badges } = recordChallengeCompleted(
          currentLesson.id,
          currentLesson.xpReward
        );
        setStreakData(updatedStreak);
        setNewlyEarnedBadges(badges);
        setIsSuccessModalOpen(true);

        // Sync with Firestore Cloud
        if (user) {
          syncProgressToCloud(updatedStreak, { [currentLesson.id]: codeFiles }).catch(console.error);
        }
      } else {
        playFaultAlert(isMuted);
      }
    } catch (e) {
      console.error('Error running test runner:', e);
    } finally {
      setIsRunningTests(false);
    }
  }, [currentLesson, codeFiles, isMuted, user, syncProgressToCloud]);

  // Manual Progress Save (Ctrl+S)
  const handleManualSave = useCallback(() => {
    try {
      localStorage.setItem(`codecraft_code_${currentLesson.id}`, JSON.stringify(codeFiles));
      localStorage.setItem('codecraft_current_lesson', currentLessonId);

      if (user) {
        syncProgressToCloud(streakData, { [currentLesson.id]: codeFiles }).catch(console.error);
        setSaveToast('Progress saved to Cloud & Local!');
      } else {
        setSaveToast('Progress saved locally!');
      }

      setTimeout(() => setSaveToast(null), 2400);
    } catch (err) {
      console.error('Error saving progress:', err);
      setSaveToast('Could not save progress');
      setTimeout(() => setSaveToast(null), 2400);
    }
  }, [codeFiles, currentLesson.id, currentLessonId, user, streakData, syncProgressToCloud]);

  // Focus Sidebar (Alt+L)
  const handleFocusSidebar = useCallback(() => {
    setSidebarOpen(true);
    setTimeout(() => {
      const activeBtn = document.getElementById('active-lesson-btn');
      if (activeBtn) {
        activeBtn.focus();
      } else {
        const firstBtn = document.querySelector('aside button');
        (firstBtn as HTMLElement)?.focus();
      }
    }, 60);
  }, []);

  // Global Keyboard Shortcuts: Ctrl+Enter (Run), Ctrl+S (Save), Alt+L (Sidebar)
  useEffect(() => {
    const handleGlobalShortcuts = (e: KeyboardEvent) => {
      // 1. Ctrl+Enter or Cmd+Enter -> Run & Test Code
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRunCode();
        return;
      }

      // 2. Ctrl+S or Cmd+S -> Save progress manually
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        handleManualSave();
        return;
      }

      // 3. Alt+L or Option+L -> Focus the sidebar
      if (e.altKey && (e.key === 'l' || e.key === 'L')) {
        e.preventDefault();
        handleFocusSidebar();
        return;
      }
    };

    window.addEventListener('keydown', handleGlobalShortcuts);
    return () => window.removeEventListener('keydown', handleGlobalShortcuts);
  }, [handleRunCode, handleManualSave, handleFocusSidebar]);

  // Next lesson navigation
  const handleNextLesson = () => {
    const currentIndex = LESSONS.findIndex((l) => l.id === currentLessonId);
    if (currentIndex >= 0 && currentIndex < LESSONS.length - 1) {
      handleSelectLesson(LESSONS[currentIndex + 1].id);
    }
    setIsSuccessModalOpen(false);
  };

  // Switch to first lesson of selected track from header dropdown
  const handleSelectTrack = (trackId: TrackId) => {
    const firstLessonInTrack = LESSONS.find((l) => l.trackId === trackId);
    if (firstLessonInTrack) {
      handleSelectLesson(firstLessonInTrack.id);
    }
  };

  // Ask AI Fault Doctor (Gemini 3.8 Flash)
  const handleAskAiDoctor = async () => {
    setIsLoadingAi(true);
    setIsAiDoctorModalOpen(true);
    setAiDoctorResult(null);

    const failingTests = testResults
      .filter((r) => !r.passed)
      .map((r) => ({
        title: r.faultTitle || r.description,
        faultMessage: r.faultMessage || '',
        explanation: r.faultExplanation || '',
        hint: r.fixSuggestion || '',
      }));

    try {
      const response = await fetch('/api/fault-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          challengeTitle: currentLesson.title,
          instructions: currentLesson.instructions.join('\n'),
          expectedGoal: currentLesson.expectedGoal,
          userCode: codeFiles,
          failingTests,
        }),
      });

      if (!response.ok) {
        throw new Error('Server error');
      }

      const data = await response.json();
      setAiDoctorResult(data);
    } catch (err) {
      console.error(err);
      // Fallback beginner-friendly analysis if offline
      const primaryFail = testResults.find((t) => !t.passed);
      setAiDoctorResult({
        faultSummary: primaryFail?.faultTitle || 'Syntax or Structural Mistake',
        beginnerExplanation:
          primaryFail?.faultExplanation ||
          'In programming, code must match exact tag names, closing brackets, or spelling. A small typo can cause the browser to miss your element.',
        analogy: 'Like typing a phone number with one missing digit — the call cannot connect!',
        actionableTip: primaryFail?.fixSuggestion || 'Review your code carefully against the challenge instructions.',
      });
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30">
      {/* Top Header */}
      <Header
        currentTrackId={currentLesson.trackId}
        onSelectTrack={handleSelectTrack}
        streakData={streakData}
        onOpenStreakModal={() => setIsStreakModalOpen(true)}
        onOpenGlossary={() => setIsGlossaryModalOpen(true)}
        onOpenSandbox={() => setIsSandboxModalOpen(true)}
        onOpenRoadmap={() => setIsRoadmapModalOpen(true)}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        isMuted={isMuted}
        onToggleMute={toggleMute}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Curriculum Navigation Sidebar */}
        <LessonSidebar
          currentLessonId={currentLessonId}
          onSelectLesson={handleSelectLesson}
          streakData={streakData}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />

        {/* Learning & Coding Workspace */}
        <main className="flex-1 flex flex-col xl:flex-row overflow-y-auto xl:overflow-hidden p-3 sm:p-4 gap-4">
          {/* Left Column (Lesson Guide & Tasks) */}
          <div className="w-full xl:w-[420px] 2xl:w-[460px] flex flex-col shrink-0 gap-4">
            <LessonGuide
              lesson={currentLesson}
              onRun={handleRunCode}
              isRunning={isRunningTests}
            />
          </div>

          {/* Right Column (Editor, Live Preview, and Fault Inspector) */}
          <div className="flex-1 flex flex-col gap-4 min-w-0">
            {/* Editor & Preview Split View */}
            <div className="flex-1 flex flex-col lg:flex-row gap-4 min-h-[460px] lg:min-h-0">
              {/* Code Editor */}
              <CodeEditor
                files={codeFiles}
                onChange={setCodeFiles}
                onReset={handleResetCode}
                onRun={handleRunCode}
                isRunning={isRunningTests}
                onSave={handleManualSave}
              />

              {/* Live Preview / Virtual Console */}
              <PreviewPane
                files={codeFiles}
                consoleLogs={consoleLogs}
                onClearConsole={() => setConsoleLogs([])}
                onRun={handleRunCode}
                isRunning={isRunningTests}
              />
            </div>

            {/* Bottom Fault Inspector Panel */}
            <FaultInspector
              lesson={currentLesson}
              testResults={testResults}
              allPassed={allPassed}
              hasRunTests={hasRunTests}
              onAskAiDoctor={handleAskAiDoctor}
              isLoadingAi={isLoadingAi}
              onNextLesson={handleNextLesson}
              onRun={handleRunCode}
              isRunning={isRunningTests}
            />
          </div>
        </main>
      </div>

      {/* Floating Quick Action: Run & Test Code Button */}
      <div className="fixed bottom-4 right-4 z-30 flex items-center gap-2">
        <button
          onClick={handleRunCode}
          disabled={isRunningTests}
          className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm shadow-2xl shadow-emerald-500/40 ring-4 ring-emerald-500/20 transition-all transform hover:scale-105 active:scale-95 cursor-pointer disabled:opacity-50"
          title="Run Code & Test Solution (Ctrl+Enter)"
        >
          <Play className={`w-4 h-4 fill-slate-950 ${isRunningTests ? 'animate-spin' : ''}`} />
          <span>{isRunningTests ? 'Testing Solution...' : 'Run & Test Code'}</span>
          <span className="hidden sm:inline text-xs font-mono opacity-80 bg-black/15 px-1.5 py-0.5 rounded">Ctrl+↵</span>
        </button>
      </div>

      {/* Manual Save Toast (Ctrl+S) */}
      {saveToast && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-emerald-500/60 text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-fadeIn ring-4 ring-emerald-500/20">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{saveToast}</span>
          <span className="text-[10px] text-slate-400 font-mono bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
            Ctrl+S
          </span>
        </div>
      )}

      {/* Interactive Modals */}
      <StreakModal
        isOpen={isStreakModalOpen}
        onClose={() => setIsStreakModalOpen(false)}
        streakData={streakData}
      />

      <AiDoctorModal
        isOpen={isAiDoctorModalOpen}
        onClose={() => setIsAiDoctorModalOpen(false)}
        result={aiDoctorResult}
        isLoading={isLoadingAi}
        challengeTitle={currentLesson.title}
      />

      <SuccessModal
        isOpen={isSuccessModalOpen}
        onClose={() => setIsSuccessModalOpen(false)}
        onNextLesson={handleNextLesson}
        lesson={currentLesson}
        newlyEarnedBadges={newlyEarnedBadges}
        streakDays={streakData.currentStreak}
      />

      <GlossaryModal
        isOpen={isGlossaryModalOpen}
        onClose={() => setIsGlossaryModalOpen(false)}
      />

      <SandboxModal
        isOpen={isSandboxModalOpen}
        onClose={() => setIsSandboxModalOpen(false)}
      />

      <RoadmapModal
        isOpen={isRoadmapModalOpen}
        onClose={() => setIsRoadmapModalOpen(false)}
        currentLessonId={currentLessonId}
        onSelectLesson={handleSelectLesson}
        streakData={streakData}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}
