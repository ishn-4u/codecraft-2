import { Lesson, TrackId } from '../types';

export const TRACK_METADATA: Record<TrackId, { title: string; description: string; icon: string; color: string }> = {
  html: {
    title: 'Track 1: HTML Fundamentals',
    description: 'The skeleton of the web. Learn elements, tags, attributes, links, forms, and semantic markup with zero prior knowledge.',
    icon: 'CodeXml',
    color: 'from-orange-500 to-amber-500',
  },
  css: {
    title: 'Track 2: CSS Styling & Layouts',
    description: 'The visual styling. Master colors, fonts, margins, the Box Model, Flexbox superpowers, and responsive designs.',
    icon: 'Palette',
    color: 'from-blue-500 to-cyan-500',
  },
  javascript: {
    title: 'Track 3: JavaScript Logic & DOM',
    description: 'The brains of the web. Discover variables, functions, conditional choices, DOM manipulation, and user click events.',
    icon: 'FileCode',
    color: 'from-amber-400 to-yellow-500',
  },
  frontend: {
    title: 'Track 4: Modern Front-End & UI',
    description: 'Component architecture, reactive state, event pipelines, and dynamic modern user interface patterns.',
    icon: 'Layers',
    color: 'from-purple-500 to-pink-500',
  },
  backend: {
    title: 'Track 5: Back-End & Full-Stack',
    description: 'How client and server talk. HTTP, JSON data payloads, REST APIs, async fetch, and database concepts.',
    icon: 'Server',
    color: 'from-emerald-500 to-teal-500',
  },
};

export const LESSONS: Lesson[] = [
  // ==========================================
  // TRACK 1: HTML
  // ==========================================
  {
    id: 'html-1',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 1,
    title: 'Your First Web Element: The Magic of Tags',
    subtitle: 'Learn how browsers read tags and create your very first heading',
    category: 'lesson',
    difficulty: 'Absolute Beginner',
    estimatedTime: '5 mins',
    conceptExplanation: `Every web page you have ever visited is built using **HTML** (HyperText Markup Language).

Think of HTML tags like a **sandwich**:
1. **Opening Tag (Top bun)**: \`<h1>\` tells the browser "A main heading starts here!"
2. **Content (The filling)**: \`Hello, World!\` the text you want the world to see.
3. **Closing Tag (Bottom bun)**: \`</h1>\` with a forward slash \`/\`, telling the browser "The heading ends here!"

Without the closing tag or the forward slash, the browser doesn't know where your heading stops, causing layout bugs!`,
    zeroKnowledgeTips: [
      'The forward slash `/` is the magic character that tells the browser a tag is closing.',
      'Always keep tags in lowercase, like `<h1>`, not `<H1>`.',
      'The characters `<` and `>` are called angle brackets.',
    ],
    commonMistakes: [
      {
        mistake: 'Writing <h1>Hello World<h1> without the forward slash in the second tag',
        why: 'The browser treats both as opening tags, confusing the document structure.',
        solution: 'Add a forward slash to the closing tag: </h1>',
      },
      {
        mistake: 'Using backslash </h1> instead of forward slash </h1>',
        why: 'HTML requires the forward slash `/` right after `<`.',
        solution: 'Use `/` located on the question mark key.',
      },
    ],
    initialFiles: {
      html: `<!-- Type your code below this comment! -->\n`,
      css: `body {\n  font-family: system-ui, sans-serif;\n  padding: 24px;\n  background: #f8fafc;\n  color: #0f172a;\n}`,
      js: ``,
    },
    solutionFiles: {
      html: `<h1>Hello, World!</h1>`,
      css: `body {\n  font-family: system-ui, sans-serif;\n  padding: 24px;\n  background: #f8fafc;\n  color: #0f172a;\n}`,
      js: ``,
    },
    instructions: [
      'Type an opening heading tag `<h1>`.',
      'Inside the tag, write the exact text `Hello, World!`.',
      'Close the tag with a matching `</h1>`.',
    ],
    expectedGoal: 'Display a main heading <h1> with the exact text "Hello, World!" on the screen.',
    hints: [
      'Remember the sandwich rule: <h1> + your text + </h1>',
      'Check your punctuation: Did you include the comma and exclamation mark in "Hello, World!"?',
    ],
    tests: [
      {
        id: 't-h1-exists',
        description: 'Should contain an <h1> element',
        faultTitle: 'Missing <h1> tag',
        faultExplanation: 'Your code does not contain an opening <h1> tag. The browser needs <h1> to recognize a primary heading.',
        fixSuggestion: 'Start by typing <h1>',
        type: 'html-selector',
        selector: 'h1',
      },
      {
        id: 't-h1-closed',
        description: 'The <h1> tag must be properly closed with </h1>',
        faultTitle: 'Unclosed <h1> tag',
        faultExplanation: 'You opened an <h1> tag, but did not properly close it with </h1>. The forward slash `/` is required.',
        fixSuggestion: 'Make sure your text is followed by </h1>',
        type: 'html-contains',
        expectedText: '</h1>',
      },
      {
        id: 't-h1-text',
        description: 'The <h1> must contain "Hello, World!"',
        faultTitle: 'Incorrect heading text',
        faultExplanation: 'The text inside your <h1> tag does not match "Hello, World!". Programming is strict with spelling, capitalization, and punctuation.',
        fixSuggestion: 'Ensure the text is exactly Hello, World! with capital H, capital W, comma, and exclamation mark.',
        type: 'dom-text',
        selector: 'h1',
        expectedText: 'Hello, World!',
      },
    ],
    xpReward: 30,
  },

  {
    id: 'html-2',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 2,
    title: 'Headings Hierarchy & Paragraphs',
    subtitle: 'Structuring content with subheadings and regular paragraph text',
    category: 'lesson',
    difficulty: 'Absolute Beginner',
    estimatedTime: '6 mins',
    conceptExplanation: `In a real book or newspaper, you have big titles, sub-headlines, and body paragraphs. HTML has tags for all of these!

- \`<h1>\` is the **most important** title (use only once per page).
- \`<h2>\` is a **subheading** (like a chapter title).
- \`<h3>\` to \`<h6>\` are progressively smaller sub-sections.
- \`<p>\` is a **paragraph** tag used for normal body sentences.

Example:
\`\`\`html
<h1>My Awesome Blog</h1>
<h2>About the Author</h2>
<p>I started coding today and it feels like a superpower.</p>
\`\`\``,
    zeroKnowledgeTips: [
      'Never use <h1> multiple times on the same page for styling; use <h2> for subtopics.',
      'The <p> tag automatically adds a clean breathing space (margin) above and below your text.',
    ],
    commonMistakes: [
      {
        mistake: 'Putting <p> inside <h2>',
        why: 'Headings should only contain plain text, not paragraphs nested inside them.',
        solution: 'Place the <p> tag right after the closing </h2> tag.',
      },
    ],
    initialFiles: {
      html: `<h1>My Coding Journey</h1>\n<!-- Add an <h2> and a <p> below -->\n`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; color: #1e293b; }`,
      js: ``,
    },
    solutionFiles: {
      html: `<h1>My Coding Journey</h1>\n<h2>About Me</h2>\n<p>I am learning to code today!</p>`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; color: #1e293b; }`,
      js: ``,
    },
    instructions: [
      'Keep the existing `<h1>` title.',
      'Directly below it, add an `<h2>` subheading with the text: `About Me`.',
      'Below the subheading, add a paragraph `<p>` with the text: `I am learning to code today!`.',
    ],
    expectedGoal: 'Create an <h2> containing "About Me" and a <p> containing "I am learning to code today!".',
    hints: [
      'Write <h2>About Me</h2> on a new line.',
      'Then write <p>I am learning to code today!</p> below it.',
    ],
    tests: [
      {
        id: 't-h2-exists',
        description: 'Must have an <h2> with "About Me"',
        faultTitle: 'Missing or incorrect <h2> subheading',
        faultExplanation: 'We could not find an <h2> tag with the text "About Me". Did you forget to close it or make a typo?',
        fixSuggestion: 'Check that you typed: <h2>About Me</h2>',
        type: 'dom-text',
        selector: 'h2',
        expectedText: 'About Me',
      },
      {
        id: 't-p-exists',
        description: 'Must have a <p> with "I am learning to code today!"',
        faultTitle: 'Missing or incorrect <p> paragraph',
        faultExplanation: 'We could not find a <p> tag containing "I am learning to code today!".',
        fixSuggestion: 'Add <p>I am learning to code today!</p>',
        type: 'dom-text',
        selector: 'p',
        expectedText: 'I am learning to code today!',
      },
    ],
    xpReward: 35,
  },

  {
    id: 'html-3',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 3,
    title: 'Hyperlinks: Connecting the Entire Web',
    subtitle: 'Learn how attributes work with anchor tags to create clickable links',
    category: 'lesson',
    difficulty: 'Absolute Beginner',
    estimatedTime: '7 mins',
    conceptExplanation: `What makes the World Wide Web "webbed" together? **Hyperlinks**!

To create a link, we use the anchor tag \`<a>\`. But a link needs to know **where** to take the user. We give tags extra powers using **Attributes**.

An attribute lives *inside* the opening tag:
\`\`\`html
<a href="https://example.com">Visit Example</a>
\`\`\`
- \`href\` stands for "Hypertext Reference" (the destination web address).
- The URL must be surrounded by quotation marks \`"..."\`.
- The text between \`<a>\` and \`</a>\` is what the user clicks on!`,
    zeroKnowledgeTips: [
      'Think of attributes like adjectives describing a noun: they configure how a tag behaves.',
      'Always include the https:// prefix when linking to external websites.',
    ],
    commonMistakes: [
      {
        mistake: '<a href=https://google.com> without quotation marks',
        why: 'Missing quotation marks can break URLs with special symbols or spaces.',
        solution: 'Wrap the URL in quotes: href="https://google.com"',
      },
      {
        mistake: 'Typing herf instead of href',
        why: 'A very common beginner typo! The browser will ignore invalid attributes.',
        solution: 'Spell it: h - r - e - f.',
      },
    ],
    initialFiles: {
      html: `<h1>Explore the Web</h1>\n<!-- Add your <a> link below -->\n`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\na { color: #2563eb; font-weight: 600; text-decoration: underline; }`,
      js: ``,
    },
    solutionFiles: {
      html: `<h1>Explore the Web</h1>\n<a href="https://google.com">Search the Web</a>`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\na { color: #2563eb; font-weight: 600; text-decoration: underline; }`,
      js: ``,
    },
    instructions: [
      'Create an anchor tag `<a>`.',
      'Give it an `href` attribute pointing to `"https://google.com"`.',
      'Set the clickable text inside to `Search the Web`.',
      'Properly close the tag with `</a>`.',
    ],
    expectedGoal: 'Create a link: <a href="https://google.com">Search the Web</a>',
    hints: [
      'The format is: <a href="URL">CLICKABLE TEXT</a>',
      'Double check that the attribute name is href (not herf or link).',
    ],
    tests: [
      {
        id: 't-a-exists',
        description: 'Contains an <a> anchor element',
        faultTitle: 'No <a> tag found',
        faultExplanation: 'Your code does not contain an <a> tag. Links in HTML always use the <a> tag.',
        fixSuggestion: 'Write <a href="...">...</a>',
        type: 'html-selector',
        selector: 'a',
      },
      {
        id: 't-a-href',
        description: 'The <a> has href="https://google.com"',
        faultTitle: 'Incorrect or missing href attribute',
        faultExplanation: 'The <a> tag needs an href attribute set exactly to "https://google.com". Did you misspell href or forget quotes?',
        fixSuggestion: 'Ensure your tag starts with: <a href="https://google.com">',
        type: 'html-attr',
        selector: 'a',
        expectedAttr: { name: 'href', valueRegex: 'https://google\\.com/?' },
      },
      {
        id: 't-a-text',
        description: 'The link text is "Search the Web"',
        faultTitle: 'Wrong link text',
        faultExplanation: 'The user should see and click "Search the Web", but we found different text inside your <a> tag.',
        fixSuggestion: 'Place Search the Web between <a> and </a>',
        type: 'dom-text',
        selector: 'a',
        expectedText: 'Search the Web',
      },
    ],
    xpReward: 35,
  },

  {
    id: 'html-4',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 4,
    title: 'Images & The Essential Alt Text',
    subtitle: 'Learn self-closing tags and accessibility with image attributes',
    category: 'lesson',
    difficulty: 'Absolute Beginner',
    estimatedTime: '6 mins',
    conceptExplanation: `Websites would be boring without images! To show a picture, we use the \`<img>\` tag.

Images are unique because they are **Self-Closing** (or void) tags. Since an image has no text inside it, you do **not** write \`</img>\`!

An \`<img>\` tag requires two essential attributes:
1. \`src\` (Source): Where the image file lives.
2. \`alt\` (Alternative text): A description of the image for blind users with screen readers, or if the image fails to load.

Example:
\`\`\`html
<img src="https://example.com/cat.jpg" alt="A fluffy orange cat sleeping on a rug">
\`\`\``,
    zeroKnowledgeTips: [
      'Never skip the alt attribute! It makes the web accessible to millions of people with visual impairments.',
      'Self-closing tags do not need a closing tag like </img>.',
    ],
    commonMistakes: [
      {
        mistake: 'Writing <img ...></img>',
        why: '<img> is a void element in HTML; it cannot contain child elements or closing tags.',
        solution: 'Just write <img src="..." alt="..."> without </img>.',
      },
      {
        mistake: 'Typing scr="..." instead of src="..."',
        why: 'Very common mistake! src stands for "source", not "screen".',
        solution: 'Spell it s - r - c.',
      },
    ],
    initialFiles: {
      html: `<h2>My Favorite Photo</h2>\n<!-- Add the <img> tag below -->\n`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\nimg { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); }`,
      js: ``,
    },
    solutionFiles: {
      html: `<h2>My Favorite Photo</h2>\n<img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400" alt="Laptop showing code on a desk">`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\nimg { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); }`,
      js: ``,
    },
    instructions: [
      'Add an `<img>` tag.',
      'Set `src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400"`.',
      'Set `alt="Laptop showing code on a desk"`.',
      'Do not write an `</img>` closing tag.',
    ],
    expectedGoal: 'Display a picture using <img src="..." alt="..."> with alt text for accessibility.',
    hints: [
      'Format: <img src="URL" alt="DESCRIPTION">',
      'Be careful with the spelling of src (not scr).',
    ],
    tests: [
      {
        id: 't-img-exists',
        description: 'Contains an <img> element',
        faultTitle: 'Missing <img> tag',
        faultExplanation: 'No <img> tag was found in the HTML.',
        fixSuggestion: 'Write <img src="..." alt="...">',
        type: 'html-selector',
        selector: 'img',
      },
      {
        id: 't-img-src',
        description: 'The <img> has a valid src attribute',
        faultTitle: 'Missing or misspelled src attribute',
        faultExplanation: 'Your <img> element is missing the src attribute or it was misspelled as "scr" or "source".',
        fixSuggestion: 'Check that src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400"',
        type: 'html-attr',
        selector: 'img',
        expectedAttr: { name: 'src', valueRegex: 'images\\.unsplash\\.com' },
      },
      {
        id: 't-img-alt',
        description: 'The <img> has alt="Laptop showing code on a desk"',
        faultTitle: 'Missing or incorrect alt attribute',
        faultExplanation: 'Screen readers need the alt description. We did not find alt="Laptop showing code on a desk".',
        fixSuggestion: 'Add alt="Laptop showing code on a desk" inside your <img> tag.',
        type: 'html-attr',
        selector: 'img',
        expectedAttr: { name: 'alt', valueRegex: 'Laptop showing code on a desk' },
      },
    ],
    xpReward: 35,
  },

  {
    id: 'html-5',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 5,
    title: 'Lists: Organizing Information',
    subtitle: 'Learn parent-child tag nesting with unordered lists and list items',
    category: 'lesson',
    difficulty: 'Absolute Beginner',
    estimatedTime: '7 mins',
    conceptExplanation: `Almost every app features lists: todo items, menu items, or skills.

HTML has two main list types:
1. \`<ul>\` (**Unordered List**): Displays bullet points.
2. \`<ol>\` (**Ordered List**): Displays numbered items (1, 2, 3...).

Inside the list, each bullet is a \`<li>\` (**List Item**):
\`\`\`html
<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>JavaScript</li>
</ul>
\`\`\`
Notice how \`<li>\` is **nested** inside \`<ul>\`! Think of \`<ul>\` as the parent shopping cart and each \`<li>\` as an item inside the cart.`,
    zeroKnowledgeTips: [
      'Indent items inside lists by 2 spaces. This makes your code neat and easy to read.',
      '<li> tags should never float alone outside a <ul> or <ol>.',
    ],
    commonMistakes: [
      {
        mistake: 'Putting plain text directly inside <ul> without <li>',
        why: '<ul> can only directly contain <li> tags according to web standards.',
        solution: 'Wrap every item in <li>...</li>.',
      },
    ],
    initialFiles: {
      html: `<h2>My Tech Skills</h2>\n<!-- Create your <ul> with 3 <li> items below -->\n`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\nul { list-style-type: disc; padding-left: 20px; }\nli { margin-bottom: 8px; font-weight: 500; }`,
      js: ``,
    },
    solutionFiles: {
      html: `<h2>My Tech Skills</h2>\n<ul>\n  <li>HTML</li>\n  <li>CSS</li>\n  <li>JavaScript</li>\n</ul>`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }\nul { list-style-type: disc; padding-left: 20px; }\nli { margin-bottom: 8px; font-weight: 500; }`,
      js: ``,
    },
    instructions: [
      'Create an opening `<ul>` tag.',
      'Inside it, add three `<li>` items with the texts: `HTML`, `CSS`, and `JavaScript`.',
      'Close each `</li>` and close the `</ul>`.',
    ],
    expectedGoal: 'Create an unordered list <ul> containing 3 <li> items: HTML, CSS, and JavaScript.',
    hints: [
      'Wrap each skill in its own <li> tags: <li>HTML</li>',
      'Make sure all three <li> are inside <ul> and </ul>.',
    ],
    tests: [
      {
        id: 't-ul-exists',
        description: 'Contains a <ul> parent element',
        faultTitle: 'Missing <ul> tag',
        faultExplanation: 'No <ul> tag was found. Unordered bullet lists require a parent <ul> element.',
        fixSuggestion: 'Add <ul> at the start and </ul> at the end.',
        type: 'html-selector',
        selector: 'ul',
      },
      {
        id: 't-li-count',
        description: 'Contains at least 3 <li> list items',
        faultTitle: 'Not enough list items',
        faultExplanation: 'We found fewer than 3 <li> elements inside your list.',
        fixSuggestion: 'Make sure you have three separate <li> tags for HTML, CSS, and JavaScript.',
        type: 'html-selector',
        selector: 'ul li',
      },
      {
        id: 't-li-content',
        description: 'Contains HTML, CSS, and JavaScript items',
        faultTitle: 'Missing expected skill name',
        faultExplanation: 'Check your spelling: The list must contain "HTML", "CSS", and "JavaScript".',
        fixSuggestion: 'Double-check spelling: HTML, CSS, JavaScript.',
        type: 'html-contains',
        expectedText: 'JavaScript',
      },
    ],
    xpReward: 40,
  },

  {
    id: 'html-project',
    trackId: 'html',
    trackTitle: 'Track 1: HTML Fundamentals',
    trackNumber: 1,
    order: 6,
    title: 'Project 1: Real-World Developer Profile Card',
    subtitle: 'Combine everything you have learned into a real portfolio card',
    category: 'project',
    difficulty: 'Beginner',
    estimatedTime: '12 mins',
    conceptExplanation: `Congratulations on reaching your first real-world project!

Real developers don't write isolated tags; they compose them together into complete web components.

In this project, you will build a complete **Developer Profile Card**:
1. An \`<img>\` avatar with \`src\` and \`alt\`
2. An \`<h1>\` heading with your developer title (e.g. \`Alex the Coder\`)
3. A \`<p>\` paragraph introducing yourself
4. A \`<ul>\` list of 3 skills
5. An \`<a>\` link button to your GitHub or portfolio`,
    zeroKnowledgeTips: [
      'Take your time and build it section by section!',
      'Check the Live Preview on the right to see your card take shape.',
    ],
    commonMistakes: [
      {
        mistake: 'Forgetting closing tags in multi-line HTML',
        why: 'When building bigger components, it is easy to forget a closing </p> or </ul>.',
        solution: 'Whenever you open a tag, close it right away, then add the content inside.',
      },
    ],
    initialFiles: {
      html: `<div class="profile-card">\n  <!-- 1. Add your avatar <img> -->\n  \n  <!-- 2. Add your <h1> title -->\n  \n  <!-- 3. Add your bio <p> -->\n  \n  <!-- 4. Add your <ul> skills with 3 <li> -->\n  \n  <!-- 5. Add your portfolio <a> link -->\n  \n</div>`,
      css: `.profile-card {\n  background: white;\n  max-width: 380px;\n  margin: 20px auto;\n  padding: 24px;\n  border-radius: 16px;\n  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);\n  text-align: center;\n  border: 1px solid #e2e8f0;\n}\n.profile-card img {\n  width: 96px;\n  height: 96px;\n  border-radius: 9999px;\n  object-fit: cover;\n  margin: 0 auto 16px auto;\n  border: 3px solid #3b82f6;\n}\nh1 {\n  font-size: 22px;\n  color: #0f172a;\n  margin-bottom: 6px;\n}\np {\n  color: #64748b;\n  font-size: 14px;\n  line-height: 1.5;\n  margin-bottom: 16px;\n}\nul {\n  list-style: none;\n  padding: 0;\n  display: flex;\n  justify-content: center;\n  gap: 8px;\n  margin-bottom: 20px;\n}\nli {\n  background: #eff6ff;\n  color: #1d4ed8;\n  padding: 4px 12px;\n  border-radius: 9999px;\n  font-size: 12px;\n  font-weight: 600;\n}\na {\n  display: inline-block;\n  background: #2563eb;\n  color: white;\n  text-decoration: none;\n  padding: 10px 20px;\n  border-radius: 8px;\n  font-weight: 600;\n  font-size: 14px;\n}`,
      js: ``,
    },
    solutionFiles: {
      html: `<div class="profile-card">\n  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200" alt="Developer portrait">\n  <h1>Alex the Coder</h1>\n  <p>Junior developer building cool web experiences every single day.</p>\n  <ul>\n    <li>HTML</li>\n    <li>CSS</li>\n    <li>Web Design</li>\n  </ul>\n  <a href="https://github.com">View Projects</a>\n</div>`,
      css: `.profile-card {\n  background: white;\n  max-width: 380px;\n  margin: 20px auto;\n  padding: 24px;\n  border-radius: 16px;\n  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);\n  text-align: center;\n  border: 1px solid #e2e8f0;\n}\n.profile-card img {\n  width: 96px;\n  height: 96px;\n  border-radius: 9999px;\n  object-fit: cover;\n  margin: 0 auto 16px auto;\n  border: 3px solid #3b82f6;\n}\nh1 {\n  font-size: 22px;\n  color: #0f172a;\n  margin-bottom: 6px;\n}\np {\n  color: #64748b;\n  font-size: 14px;\n  line-height: 1.5;\n  margin-bottom: 16px;\n}\nul {\n  list-style: none;\n  padding: 0;\n  display: flex;\n  justify-content: center;\n  gap: 8px;\n  margin-bottom: 20px;\n}\nli {\n  background: #eff6ff;\n  color: #1d4ed8;\n  padding: 4px 12px;\n  border-radius: 9999px;\n  font-size: 12px;\n  font-weight: 600;\n}\na {\n  display: inline-block;\n  background: #2563eb;\n  color: white;\n  text-decoration: none;\n  padding: 10px 20px;\n  border-radius: 8px;\n  font-weight: 600;\n  font-size: 14px;\n}`,
      js: ``,
    },
    instructions: [
      'Inside `.profile-card`, add an `<img>` tag with `src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200"` and an `alt` description.',
      'Add an `<h1>` with your developer name.',
      'Add a `<p>` paragraph with a brief bio.',
      'Add a `<ul>` containing 3 `<li>` items with your current skills.',
      'Add an `<a>` link with an `href` attribute (e.g. to https://github.com) and button text.',
    ],
    expectedGoal: 'Build a fully formed HTML developer bio card with avatar, name, bio, skills, and portfolio link.',
    hints: [
      'Check the CSS tab to see how styles automatically decorate your card!',
      'Make sure every opening tag has its matching closing tag.',
    ],
    tests: [
      {
        id: 't-p-img',
        description: 'Profile has an <img> with alt attribute',
        faultTitle: 'Missing avatar image or alt text',
        faultExplanation: 'Your profile card needs an <img> with both src and alt attributes.',
        fixSuggestion: 'Add <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200" alt="Avatar">',
        type: 'html-attr',
        selector: '.profile-card img',
        expectedAttr: { name: 'alt', required: true },
      },
      {
        id: 't-p-h1',
        description: 'Profile has an <h1> title',
        faultTitle: 'Missing <h1> title',
        faultExplanation: 'Every profile card needs a main heading <h1> for the name.',
        fixSuggestion: 'Add <h1>Your Name</h1>',
        type: 'html-selector',
        selector: '.profile-card h1',
      },
      {
        id: 't-p-p',
        description: 'Profile has a <p> bio paragraph',
        faultTitle: 'Missing <p> bio',
        faultExplanation: 'Add a <p> tag with a short sentence describing yourself.',
        fixSuggestion: 'Add <p>Aspiring developer learning HTML!</p>',
        type: 'html-selector',
        selector: '.profile-card p',
      },
      {
        id: 't-p-skills',
        description: 'Profile has a <ul> with at least 3 <li> skills',
        faultTitle: 'Skills list incomplete',
        faultExplanation: 'The profile needs a <ul> containing at least 3 <li> items.',
        fixSuggestion: 'Add <ul><li>HTML</li><li>CSS</li><li>Web</li></ul>',
        type: 'html-selector',
        selector: '.profile-card ul li',
      },
      {
        id: 't-p-link',
        description: 'Profile has a clickable <a> link button with href',
        faultTitle: 'Missing portfolio link',
        faultExplanation: 'We need an <a> tag with an href attribute so visitors can click to see more.',
        fixSuggestion: 'Add <a href="https://github.com">View Projects</a>',
        type: 'html-attr',
        selector: '.profile-card a',
        expectedAttr: { name: 'href', required: true },
      },
    ],
    xpReward: 60,
  },

  // ==========================================
  // TRACK 2: CSS
  // ==========================================
  {
    id: 'css-1',
    trackId: 'css',
    trackTitle: 'Track 2: CSS Styling & Layouts',
    trackNumber: 2,
    order: 7,
    title: 'Your First CSS: Selectors & Colors',
    subtitle: 'Learn CSS syntax rules: selector, property, and value',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '6 mins',
    conceptExplanation: `HTML gives the web its bones; **CSS** (Cascading Style Sheets) gives it beauty, color, and fashion!

Every CSS rule has three key parts:
\`\`\`css
selector {
  property: value;
}
\`\`\`
1. **Selector**: Tells the browser *who* to style (e.g. \`h1\`, \`p\`, or a class like \`.btn\`).
2. **Curly Braces \`{ ... }\`**: Wrap the style instructions.
3. **Property & Value**: What you want to change (e.g. \`color: #4f46e5;\`).
4. **Semicolon \`;\`**: Every single CSS declaration **MUST** end with a semicolon!`,
    zeroKnowledgeTips: [
      'Forgetting the semicolon `;` at the end of a CSS line is the #1 mistake new coders make.',
      'Colors can be named (like `blue`), hex codes (like `#4f46e5`), or `rgb()`.',
    ],
    commonMistakes: [
      {
        mistake: 'h1 { color: red } without semicolon',
        why: 'While the last rule might sometimes work, subsequent rules will completely break without semicolons.',
        solution: 'Always end every CSS property line with a semicolon `;`.',
      },
      {
        mistake: 'Using equal sign h1 { color = blue; }',
        why: 'CSS uses colons `:`, not equal signs `=`.',
        solution: 'Write color: blue;',
      },
    ],
    initialFiles: {
      html: `<h1>Welcome to Beautiful CSS</h1>\n<p>CSS makes the web vibrant and exciting.</p>`,
      css: `/* Add your CSS styles below */\n`,
      js: ``,
    },
    solutionFiles: {
      html: `<h1>Welcome to Beautiful CSS</h1>\n<p>CSS makes the web vibrant and exciting.</p>`,
      css: `h1 {\n  color: #4f46e5;\n}\np {\n  color: #64748b;\n}`,
      js: ``,
    },
    instructions: [
      'In the CSS tab, target the `h1` selector.',
      'Set its `color` property to `#4f46e5` (a vibrant indigo).',
      'Target the `p` selector and set its `color` to `#64748b` (a clean slate gray).',
      'Make sure both lines end with a semicolon `;`!',
    ],
    expectedGoal: 'Style <h1> with color: #4f46e5; and <p> with color: #64748b;.',
    hints: [
      'Write: h1 { color: #4f46e5; }',
      'Then write: p { color: #64748b; }',
    ],
    tests: [
      {
        id: 't-css-h1-color',
        description: 'The <h1> element has color: #4f46e5',
        faultTitle: 'Incorrect <h1> color',
        faultExplanation: 'The <h1> color does not match #4f46e5. Did you forget the colon, the semicolon, or the # symbol?',
        fixSuggestion: 'Check: h1 { color: #4f46e5; }',
        type: 'expected-css' as any,
        expectedCss: { selector: 'h1', property: 'color', value: ['rgb(79, 70, 229)', '#4f46e5'] },
      },
      {
        id: 't-css-p-color',
        description: 'The <p> element has color: #64748b',
        faultTitle: 'Incorrect <p> color',
        faultExplanation: 'The <p> element color was not set to #64748b.',
        fixSuggestion: 'Write: p { color: #64748b; }',
        type: 'expected-css' as any,
        expectedCss: { selector: 'p', property: 'color', value: ['rgb(100, 116, 139)', '#64748b'] },
      },
    ],
    xpReward: 35,
  },

  {
    id: 'css-2',
    trackId: 'css',
    trackTitle: 'Track 2: CSS Styling & Layouts',
    trackNumber: 2,
    order: 8,
    title: 'The Box Model: Margin, Border, & Padding',
    subtitle: 'The fundamental secret to spacing elements on the web',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '8 mins',
    conceptExplanation: `Every single element on a web page is secretly a **rectangular box**! Understanding the **Box Model** is the difference between struggling with layouts and mastering them.

From inside to outside:
1. **Content**: The text or image itself.
2. **Padding**: Breathing room *inside* the box, between the content and the border (like bubble wrap).
3. **Border**: The frame around the box.
4. **Margin**: Spacing *outside* the box, pushing other elements away.

Example:
\`\`\`css
.card {
  padding: 20px;
  border: 2px solid #3b82f6;
  border-radius: 12px;
  margin: 16px;
}
\`\`\``,
    zeroKnowledgeTips: [
      'Padding pushes inward from the border. Margin pushes outward from the border.',
      '`border-radius` rounds the sharp corners into smooth curves.',
    ],
    commonMistakes: [
      {
        mistake: 'border: 2px #3b82f6; without the style word "solid"',
        why: 'In CSS, borders require three parts: width (2px), style (solid), and color (#3b82f6). Without "solid", the border is invisible!',
        solution: 'Write: border: 2px solid #3b82f6;',
      },
    ],
    initialFiles: {
      html: `<div class="card">\n  <h2>Special Announcement</h2>\n  <p>Learn how padding and borders transform plain text into a card!</p>\n</div>`,
      css: `/* Style the .card element below */\n.card {\n  background-color: #ffffff;\n}\n`,
      js: ``,
    },
    solutionFiles: {
      html: `<div class="card">\n  <h2>Special Announcement</h2>\n  <p>Learn how padding and borders transform plain text into a card!</p>\n</div>`,
      css: `.card {\n  background-color: #ffffff;\n  padding: 24px;\n  border: 2px solid #3b82f6;\n  border-radius: 12px;\n}`,
      js: ``,
    },
    instructions: [
      'Inside the `.card` rule, add `padding: 24px;` to give breathing room.',
      'Add a `border: 2px solid #3b82f6;`.',
      'Add `border-radius: 12px;` to round the corners.',
    ],
    expectedGoal: 'Apply padding: 24px;, border: 2px solid #3b82f6;, and border-radius: 12px; to .card.',
    hints: [
      'Remember: border has 3 values: 2px solid #3b82f6',
      'Make sure each line ends with a semicolon ;',
    ],
    tests: [
      {
        id: 't-css-padding',
        description: '.card has 24px padding',
        faultTitle: 'Missing or wrong padding',
        faultExplanation: 'The .card does not have 24px padding. Did you write margin instead of padding, or forget px?',
        fixSuggestion: 'Add: padding: 24px;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.card', property: 'padding', value: '24px' },
      },
      {
        id: 't-css-radius',
        description: '.card has 12px border-radius',
        faultTitle: 'Missing border-radius',
        faultExplanation: 'The corners are not rounded. Check border-radius: 12px;',
        fixSuggestion: 'Add: border-radius: 12px;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.card', property: 'border-radius', value: '12px' },
      },
      {
        id: 't-css-border',
        description: '.card has a solid 2px border',
        faultTitle: 'Missing or incomplete border',
        faultExplanation: 'Remember that borders need width, style (solid), and color.',
        fixSuggestion: 'Add: border: 2px solid #3b82f6;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.card', property: 'border-width', value: '2px' },
      },
    ],
    xpReward: 40,
  },

  {
    id: 'css-3',
    trackId: 'css',
    trackTitle: 'Track 2: CSS Styling & Layouts',
    trackNumber: 2,
    order: 9,
    title: 'Flexbox Superpowers: Aligning Anything',
    subtitle: 'The modern CSS layout engine that makes centering and row layouts effortless',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '8 mins',
    conceptExplanation: `Before **Flexbox**, aligning things side-by-side or centering them was notoriously difficult in web development. Flexbox changed everything!

When you set \`display: flex;\` on a parent container:
1. All children immediately snap into a tidy row side-by-side.
2. \`justify-content: space-between;\` pushes items to opposite sides (great for navigation bars!).
3. \`align-items: center;\` perfectly centers items vertically.
4. \`gap: 16px;\` automatically adds even spacing between all items without tricky margins.

Example Navbar:
\`\`\`css
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
\`\`\``,
    zeroKnowledgeTips: [
      '`display: flex` must always be applied to the PARENT container, not the individual child items.',
      '`justify-content` controls the horizontal axis; `align-items` controls the vertical axis.',
    ],
    commonMistakes: [
      {
        mistake: 'Trying to use justify-content without writing display: flex first',
        why: 'justify-content only works when the parent is in flex or grid layout mode.',
        solution: 'Always write display: flex; first.',
      },
    ],
    initialFiles: {
      html: `<nav class="navbar">\n  <div class="logo">⚡ CodeCraft</div>\n  <div class="nav-links">\n    <span>Courses</span>\n    <span>Projects</span>\n    <button class="btn">Sign In</button>\n  </div>\n</nav>`,
      css: `.navbar {\n  background: #0f172a;\n  color: white;\n  padding: 16px 24px;\n  border-radius: 8px;\n  /* Add your Flexbox rules below */\n}\n\n.nav-links {\n  display: flex;\n  gap: 16px;\n  align-items: center;\n}\n\n.btn {\n  background: #3b82f6;\n  color: white;\n  border: none;\n  padding: 6px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n}`,
      js: ``,
    },
    solutionFiles: {
      html: `<nav class="navbar">\n  <div class="logo">⚡ CodeCraft</div>\n  <div class="nav-links">\n    <span>Courses</span>\n    <span>Projects</span>\n    <button class="btn">Sign In</button>\n  </div>\n</nav>`,
      css: `.navbar {\n  background: #0f172a;\n  color: white;\n  padding: 16px 24px;\n  border-radius: 8px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.nav-links {\n  display: flex;\n  gap: 16px;\n  align-items: center;\n}\n\n.btn {\n  background: #3b82f6;\n  color: white;\n  border: none;\n  padding: 6px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n}`,
      js: ``,
    },
    instructions: [
      'In `.navbar`, activate flexbox by setting `display: flex;`.',
      'Add `justify-content: space-between;` to push the logo to the left and links to the right.',
      'Add `align-items: center;` to vertically align everything.',
    ],
    expectedGoal: 'Turn .navbar into a flex container with display: flex;, justify-content: space-between;, and align-items: center;.',
    hints: [
      'Inside .navbar { ... }, add all 3 properties.',
      'Check spelling: justify-content with a hyphen, align-items with a hyphen.',
    ],
    tests: [
      {
        id: 't-css-flex',
        description: '.navbar has display: flex',
        faultTitle: 'Missing display: flex',
        faultExplanation: 'Flexbox properties like justify-content do nothing until display: flex is set.',
        fixSuggestion: 'Add: display: flex;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.navbar', property: 'display', value: 'flex' },
      },
      {
        id: 't-css-justify',
        description: '.navbar has justify-content: space-between',
        faultTitle: 'Missing justify-content: space-between',
        faultExplanation: 'The logo and links are not spaced apart. Use justify-content: space-between;',
        fixSuggestion: 'Add: justify-content: space-between;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.navbar', property: 'justify-content', value: 'space-between' },
      },
      {
        id: 't-css-align',
        description: '.navbar has align-items: center',
        faultTitle: 'Missing align-items: center',
        faultExplanation: 'Items are not vertically centered. Add align-items: center;',
        fixSuggestion: 'Add: align-items: center;',
        type: 'expected-css' as any,
        expectedCss: { selector: '.navbar', property: 'align-items', value: 'center' },
      },
    ],
    xpReward: 45,
  },

  // ==========================================
  // TRACK 3: JAVASCRIPT
  // ==========================================
  {
    id: 'js-1',
    trackId: 'javascript',
    trackTitle: 'Track 3: JavaScript Logic & DOM',
    trackNumber: 3,
    order: 10,
    title: 'Variables: How Computers Store Memories',
    subtitle: 'Learn const and let to store numbers, text strings, and values',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '7 mins',
    conceptExplanation: `Welcome to **JavaScript**, the programming language that makes web pages think, calculate, and react!

In code, a **variable** is like a labeled storage box where you store data for later use.

JavaScript gives us two modern ways to make variables:
1. \`const\` (**Constant**): A value that **never changes** once set (like your birthdate or user ID).
2. \`let\`: A value that **can change** later (like a game score or counter).

Data Types:
- **String (Text)**: Must be wrapped in quotes: \`const hero = "Spider-Man";\`
- **Number**: Plain digits without quotes: \`let score = 0;\`

Example:
\`\`\`js
const playerName = "Neo";
let level = 1;
level = 2; // Perfectly allowed because it's a 'let'!
\`\`\``,
    zeroKnowledgeTips: [
      'If you forget quotes around text like `const name = Alex;`, JavaScript thinks Alex is a variable and throws a ReferenceError!',
      'Default to using `const` whenever possible; only use `let` if the value will change.',
    ],
    commonMistakes: [
      {
        mistake: 'const score = 10; score = 20;',
        why: 'TypeError: Assignment to constant variable. A const cannot be reassigned!',
        solution: 'Use let score = 10; if you plan to change it.',
      },
    ],
    initialFiles: {
      html: `<div id="app" style="font-family: system-ui; padding: 24px;">\n  <h2>Player Status</h2>\n  <p>Check the Console below to see your JavaScript variables in action!</p>\n</div>`,
      css: ``,
      js: `// Declare your variables below\n\n`,
    },
    solutionFiles: {
      html: `<div id="app" style="font-family: system-ui; padding: 24px;">\n  <h2>Player Status</h2>\n  <p>Check the Console below to see your JavaScript variables in action!</p>\n</div>`,
      css: ``,
      js: `const username = "Alex";\nlet playerLevel = 1;\nconsole.log("Welcome " + username + ", Level: " + playerLevel);`,
    },
    instructions: [
      'In the JavaScript tab, declare a constant named `username` set to `"Alex"`.',
      'Declare a `let` variable named `playerLevel` set to the number `1`.',
      'Log them to the console using: `console.log(username, playerLevel);`.',
    ],
    expectedGoal: 'Declare const username = "Alex"; and let playerLevel = 1; and log them.',
    hints: [
      'Write: const username = "Alex";',
      'Write: let playerLevel = 1;',
      'Then: console.log(username, playerLevel);',
    ],
    tests: [
      {
        id: 't-js-const-username',
        description: 'username is defined and equals "Alex"',
        faultTitle: 'Variable username missing or incorrect',
        faultExplanation: 'We could not find a variable named username with value "Alex". Did you forget quotes around "Alex"?',
        fixSuggestion: 'Write: const username = "Alex";',
        type: 'js-eval',
        jsTestExpression: 'typeof username !== "undefined" && username === "Alex"',
      },
      {
        id: 't-js-let-level',
        description: 'playerLevel is defined and equals 1',
        faultTitle: 'Variable playerLevel missing or incorrect',
        faultExplanation: 'playerLevel was not declared or does not equal the number 1.',
        fixSuggestion: 'Write: let playerLevel = 1;',
        type: 'js-eval',
        jsTestExpression: 'typeof playerLevel !== "undefined" && playerLevel === 1',
      },
    ],
    xpReward: 40,
  },

  {
    id: 'js-2',
    trackId: 'javascript',
    trackTitle: 'Track 3: JavaScript Logic & DOM',
    trackNumber: 3,
    order: 11,
    title: 'Functions: Reusable Code Recipes',
    subtitle: 'Learn parameters, arguments, and the crucial return keyword',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '8 mins',
    conceptExplanation: `Imagine having to type out the same 10 lines of code every single time a user clicks a button. That would be exhausting!

A **Function** is a reusable machine: you give it inputs (**parameters**), it does work, and it sends back an output using the \`return\` keyword.

Structure:
\`\`\`js
function greetUser(name) {
  return "Hello, " + name + "!";
}

const message = greetUser("Sara"); // message is "Hello, Sara!"
\`\`\`

The \`return\` keyword is vital: it hands the final result back to whoever called the function. Without \`return\`, a function sends back \`undefined\`!`,
    zeroKnowledgeTips: [
      'Do not confuse `console.log` with `return`. `console.log` only prints to the screen for debugging; `return` gives the value back to the program.',
      'Functions are not executed until you actually call them with parentheses `()`.',
    ],
    commonMistakes: [
      {
        mistake: 'Using console.log instead of return inside a function',
        why: 'The function will complete, but whoever called it receives undefined.',
        solution: 'Use return price + tax; so the result can be saved or tested.',
      },
    ],
    initialFiles: {
      html: `<div style="font-family: system-ui; padding: 24px;">\n  <h2>Shopping Cart Calculator</h2>\n  <p>Test your calculation function in the Console!</p>\n</div>`,
      css: ``,
      js: `// Write your calculateTotal function below\n\n`,
    },
    solutionFiles: {
      html: `<div style="font-family: system-ui; padding: 24px;">\n  <h2>Shopping Cart Calculator</h2>\n  <p>Test your calculation function in the Console!</p>\n</div>`,
      css: ``,
      js: `function calculateTotal(price, taxRate) {\n  return price + (price * taxRate);\n}`,
    },
    instructions: [
      'Define a function named `calculateTotal` that takes two parameters: `price` and `taxRate`.',
      'Inside the function, calculate the tax amount (`price * taxRate`) and add it to `price`.',
      'Use the `return` keyword to return this total price.',
    ],
    expectedGoal: 'Write function calculateTotal(price, taxRate) { return price + (price * taxRate); }',
    hints: [
      'Function template: function calculateTotal(price, taxRate) { return price + (price * taxRate); }',
      'Make sure you spell calculateTotal with camelCase (capital T).',
    ],
    tests: [
      {
        id: 't-js-fn-exists',
        description: 'calculateTotal is a defined function',
        faultTitle: 'Function calculateTotal not found',
        faultExplanation: 'We could not find a function named calculateTotal. Check the spelling and make sure you used the function keyword.',
        fixSuggestion: 'Write: function calculateTotal(price, taxRate) { ... }',
        type: 'js-eval',
        jsTestExpression: 'typeof calculateTotal === "function"',
      },
      {
        id: 't-js-fn-returns',
        description: 'calculateTotal(100, 0.1) correctly returns 110',
        faultTitle: 'Wrong calculation result or missing return',
        faultExplanation: 'Calling calculateTotal(100, 0.1) did not return 110. Did you forget the return keyword or make a math error?',
        fixSuggestion: 'Ensure you write: return price + (price * taxRate);',
        type: 'js-eval',
        jsTestExpression: 'calculateTotal(100, 0.1) === 110 && calculateTotal(50, 0.2) === 60',
      },
    ],
    xpReward: 45,
  },

  {
    id: 'js-3',
    trackId: 'javascript',
    trackTitle: 'Track 3: JavaScript Logic & DOM',
    trackNumber: 3,
    order: 12,
    title: 'The DOM & Event Listeners: Responding to Clicks',
    subtitle: 'Connect your JavaScript to HTML elements to build interactive apps',
    category: 'lesson',
    difficulty: 'Beginner',
    estimatedTime: '9 mins',
    conceptExplanation: `This is where the magic happens! **The DOM** (Document Object Model) is how JavaScript talks directly to your HTML.

Step 1: **Find the HTML element** using its ID:
\`\`\`js
const myButton = document.getElementById("clickBtn");
const message = document.getElementById("status");
\`\`\`

Step 2: **Listen for user actions** with an Event Listener:
\`\`\`js
myButton.addEventListener("click", () => {
  message.textContent = "Button was clicked!";
  message.style.color = "#2563eb";
});
\`\`\`
- \`"click"\` is the event name.
- \`textContent\` changes the text inside the HTML tag instantly!`,
    zeroKnowledgeTips: [
      'Do NOT put the `#` hashtag inside `getElementById("btn")`. Hashtags are only for querySelector or CSS.',
      '`addEventListener("click", ...)` must use `"click"`, not `"onclick"`.',
    ],
    commonMistakes: [
      {
        mistake: 'document.getElementById("#status")',
        why: 'getElementById already knows it is looking for an ID, so the # symbol causes it to fail.',
        solution: 'Write document.getElementById("status") without the #.',
      },
    ],
    initialFiles: {
      html: `<div style="font-family: system-ui; padding: 24px; text-align: center;">\n  <h1 id="headline">Click the Button!</h1>\n  <button id="magicBtn" style="padding: 10px 20px; font-size: 16px; background: #3b82f6; color: white; border: none; border-radius: 8px; cursor: pointer;">\n    Surprise Me\n  </button>\n</div>`,
      css: ``,
      js: `// 1. Select the elements using document.getElementById\n\n// 2. Add a click event listener to change the headline textContent\n`,
    },
    solutionFiles: {
      html: `<div style="font-family: system-ui; padding: 24px; text-align: center;">\n  <h1 id="headline">Click the Button!</h1>\n  <button id="magicBtn" style="padding: 10px 20px; font-size: 16px; background: #3b82f6; color: white; border: none; border-radius: 8px; cursor: pointer;">\n    Surprise Me\n  </button>\n</div>`,
      css: ``,
      js: `const btn = document.getElementById("magicBtn");\nconst headline = document.getElementById("headline");\n\nbtn.addEventListener("click", () => {\n  headline.textContent = "You unlocked the secret!";\n});`,
    },
    instructions: [
      'Select the button with `document.getElementById("magicBtn")`.',
      'Select the heading with `document.getElementById("headline")`.',
      'Add a click event listener to the button.',
      'When clicked, update `headline.textContent` to `"You unlocked the secret!"`.',
    ],
    expectedGoal: 'When #magicBtn is clicked, change #headline textContent to "You unlocked the secret!".',
    hints: [
      'btn.addEventListener("click", () => { headline.textContent = "You unlocked the secret!"; });',
      'Click the button in the Live Preview on the right to test it yourself!',
    ],
    tests: [
      {
        id: 't-dom-listener',
        description: 'Clicking #magicBtn updates #headline text',
        faultTitle: 'Click event did not update headline',
        faultExplanation: 'When we triggered a click on #magicBtn, #headline text did not change to "You unlocked the secret!". Check element IDs and textContent.',
        fixSuggestion: 'Ensure: btn.addEventListener("click", () => { headline.textContent = "You unlocked the secret!"; });',
        type: 'js-eval',
        jsTestExpression: `(() => {
          const btn = document.getElementById("magicBtn");
          const h1 = document.getElementById("headline");
          if (!btn || !h1) return false;
          btn.click();
          return h1.textContent.trim() === "You unlocked the secret!";
        })()`,
      },
    ],
    xpReward: 50,
  },

  // ==========================================
  // TRACK 4: FRONTEND & REACT
  // ==========================================
  {
    id: 'frontend-1',
    trackId: 'frontend',
    trackTitle: 'Track 4: Modern Front-End & UI',
    trackNumber: 4,
    order: 13,
    title: 'Thinking in Components: UI Lego Blocks',
    subtitle: 'How modern web frameworks break pages into reusable, self-contained units',
    category: 'lesson',
    difficulty: 'Intermediate',
    estimatedTime: '9 mins',
    conceptExplanation: `In traditional web development, HTML, CSS, and JS were often kept in massive, messy files. Modern frameworks like **React** and **Vue** revolutionized this by introducing **Components**!

A component is like a custom Lego brick:
- It bundles its own markup and logic.
- It accepts custom data (**Props**).
- You can reuse it 100 times across your website without repeating code!

Example in JavaScript / JSX concept:
\`\`\`js
function UserCard(props) {
  return \`
    <div class="user-card">
      <h3>\${props.name}</h3>
      <span class="badge">\${props.role}</span>
    </div>
  \`;
}
\`\`\``,
    zeroKnowledgeTips: [
      'Component names always start with a Capital letter (e.g. `UserCard`, not `userCard`).',
      'Props are just function arguments passed as an object of options.',
    ],
    commonMistakes: [
      {
        mistake: 'Hardcoding data inside the component instead of using props',
        why: 'If you hardcode "Alex", the component cannot be reused for "Sam" or "Taylor".',
        solution: 'Reference props.name and props.role dynamically.',
      },
    ],
    initialFiles: {
      html: `<div id="container" style="font-family: system-ui; padding: 24px; display: flex; gap: 16px;"></div>`,
      css: `.user-card {\n  background: #f1f5f9;\n  border: 1px solid #cbd5e1;\n  padding: 16px;\n  border-radius: 8px;\n  min-width: 140px;\n}\n.user-card h3 { margin: 0 0 6px 0; font-size: 16px; }\n.badge { background: #3b82f6; color: white; padding: 2px 8px; border-radius: 9999px; font-size: 11px; }`,
      js: `// Build a reusable component function createBadge(name, role)\nfunction createBadge(name, role) {\n  // Return an HTML string template with .user-card, h3 with name, and span.badge with role\n  \n}\n\n// Example usage:\nconst container = document.getElementById("container");\nif (container) {\n  container.innerHTML = createBadge("Sarah", "Admin") + createBadge("Leo", "Developer");\n}`,
    },
    solutionFiles: {
      html: `<div id="container" style="font-family: system-ui; padding: 24px; display: flex; gap: 16px;"></div>`,
      css: `.user-card {\n  background: #f1f5f9;\n  border: 1px solid #cbd5e1;\n  padding: 16px;\n  border-radius: 8px;\n  min-width: 140px;\n}\n.user-card h3 { margin: 0 0 6px 0; font-size: 16px; }\n.badge { background: #3b82f6; color: white; padding: 2px 8px; border-radius: 9999px; font-size: 11px; }`,
      js: `function createBadge(name, role) {\n  return '<div class="user-card"><h3>' + name + '</h3><span class="badge">' + role + '</span></div>';\n}\n\nconst container = document.getElementById("container");\nif (container) {\n  container.innerHTML = createBadge("Sarah", "Admin") + createBadge("Leo", "Developer");\n}`,
    },
    instructions: [
      'Complete `createBadge(name, role)` so it returns an HTML template string.',
      'The returned string must contain `<div class="user-card">`, an `<h3>` displaying `name`, and `<span class="badge">` displaying `role`.',
      'The rendered cards will appear in the `#container`.',
    ],
    expectedGoal: 'Return component markup containing user-card, h3 name, and badge role.',
    hints: [
      'Use template literals: return `<div class="user-card"><h3>${name}</h3><span class="badge">${role}</span></div>`;',
    ],
    tests: [
      {
        id: 't-comp-fn',
        description: 'createBadge("Alex", "Student") generates correct HTML',
        faultTitle: 'Component function output incorrect',
        faultExplanation: 'createBadge did not return the expected HTML with user-card, h3, and span.badge.',
        fixSuggestion: 'Check: return `<div class="user-card"><h3>${name}</h3><span class="badge">${role}</span></div>`;',
        type: 'js-eval',
        jsTestExpression: `typeof createBadge === "function" && createBadge("Alex", "Student").includes("user-card") && createBadge("Alex", "Student").includes("Student")`,
      },
      {
        id: 't-comp-rendered',
        description: 'Rendered cards exist in #container',
        faultTitle: 'Cards not rendered into container',
        faultExplanation: 'We could not find .user-card elements inside #container in the preview.',
        fixSuggestion: 'Ensure container.innerHTML is populated using createBadge.',
        type: 'html-selector',
        selector: '#container .user-card',
      },
    ],
    xpReward: 50,
  },

  // ==========================================
  // TRACK 5: BACKEND & FULL-STACK
  // ==========================================
  {
    id: 'backend-1',
    trackId: 'backend',
    trackTitle: 'Track 5: Back-End & Full-Stack',
    trackNumber: 5,
    order: 14,
    title: 'How Clients & Servers Talk (JSON & HTTP)',
    subtitle: 'Demystifying APIs, status codes, and JSON data formats',
    category: 'lesson',
    difficulty: 'Intermediate',
    estimatedTime: '10 mins',
    conceptExplanation: `How does Instagram load new posts, or Spotify fetch songs? Through **APIs** (Application Programming Interfaces)!

1. **Client (Browser/Phone)**: Sends a **Request** (e.g. \`GET /api/weather\`).
2. **Server (Backend computer in the cloud)**: Processes the request, talks to the database, and sends back a **Response**.
3. **HTTP Status Codes**:
   - **200 OK**: Everything succeeded!
   - **404 Not Found**: The requested page or data doesn't exist.
   - **500 Server Error**: The backend code crashed.
4. **JSON (JavaScript Object Notation)**: The universal language both frontend and backend use to exchange data:
\`\`\`json
{
  "city": "Tokyo",
  "temperature": 22,
  "condition": "Sunny"
}
\`\`\``,
    zeroKnowledgeTips: [
      'In JSON, all property keys must be wrapped in double quotes: `"key": "value"`.',
      'JSON is just plain text structured like a JavaScript object.',
    ],
    commonMistakes: [
      {
        mistake: "Using single quotes in JSON: {'name': 'Alex'}",
        why: 'JSON strictly requires double quotes. Single quotes will fail with a SyntaxError when parsed.',
        solution: 'Always use double quotes: {"name": "Alex"}.',
      },
    ],
    initialFiles: {
      html: `<div style="font-family: system-ui; padding: 24px;">\n  <h2>API Response Parser</h2>\n  <div id="output" style="background: #1e293b; color: #38bdf8; padding: 16px; border-radius: 8px; font-family: monospace;">\n    Waiting for data...\n  </div>\n</div>`,
      css: ``,
      js: `// Simulated JSON string from a weather server\nconst jsonResponse = '{"city": "Paris", "temperature": 18, "isRaining": false}';\n\n// 1. Parse the JSON string into a JavaScript object using JSON.parse()\n\n// 2. Display the city and temperature inside #output\n`,
    },
    solutionFiles: {
      html: `<div style="font-family: system-ui; padding: 24px;">\n  <h2>API Response Parser</h2>\n  <div id="output" style="background: #1e293b; color: #38bdf8; padding: 16px; border-radius: 8px; font-family: monospace;">\n    Waiting for data...\n  </div>\n</div>`,
      css: ``,
      js: `const jsonResponse = '{"city": "Paris", "temperature": 18, "isRaining": false}';\n\nconst data = JSON.parse(jsonResponse);\nconst output = document.getElementById("output");\noutput.textContent = data.city + ": " + data.temperature + "°C";`,
    },
    instructions: [
      'Use `JSON.parse(jsonResponse)` to convert the string into an object named `data`.',
      'Select the `#output` element.',
      'Set its `textContent` to display the city and temperature (e.g. `data.city + ": " + data.temperature + "°C"`).',
    ],
    expectedGoal: 'Parse the JSON response and update #output with the city and temperature.',
    hints: [
      'const data = JSON.parse(jsonResponse);',
      'document.getElementById("output").textContent = `${data.city}: ${data.temperature}°C`;',
    ],
    tests: [
      {
        id: 't-json-parsed',
        description: 'JSON is parsed and data.city is Paris',
        faultTitle: 'JSON parsing missing',
        faultExplanation: 'Make sure you call JSON.parse(jsonResponse) and save it to a variable named data.',
        fixSuggestion: 'Write: const data = JSON.parse(jsonResponse);',
        type: 'js-eval',
        jsTestExpression: 'typeof data === "object" && data.city === "Paris"',
      },
      {
        id: 't-json-output',
        description: '#output text includes Paris',
        faultTitle: '#output not updated with parsed data',
        faultExplanation: 'The #output element does not contain the city name "Paris". Did you update textContent?',
        fixSuggestion: 'Set output.textContent = `${data.city}: ${data.temperature}°C`;',
        type: 'dom-text',
        selector: '#output',
        expectedText: 'Paris',
      },
    ],
    xpReward: 55,
  },

  {
    id: 'backend-project',
    trackId: 'backend',
    trackTitle: 'Track 5: Back-End & Full-Stack',
    trackNumber: 5,
    order: 15,
    title: 'Project 2: Full-Stack Live Data Explorer',
    subtitle: 'Fetch dynamic data asynchronously with loading states and error handling',
    category: 'project',
    difficulty: 'Intermediate',
    estimatedTime: '15 mins',
    conceptExplanation: `You have made it to the capstone full-stack project!

In real production web applications, users don't want the page to freeze while data is loading from the server. We use \`async\` and \`await\` with \`fetch()\` to grab data smoothly in the background:

\`\`\`js
async function loadUserData() {
  statusDiv.textContent = "Loading...";
  try {
    const res = await fetch("/api/user");
    const data = await res.json();
    statusDiv.textContent = "Hello " + data.name;
  } catch (err) {
    statusDiv.textContent = "Error loading data!";
  }
}
\`\`\`

In this project, you will wire up an interactive Quote & Wisdom Generator that fetches random coding quotes with smooth UI states!`,
    zeroKnowledgeTips: [
      '`async` marks a function as asynchronous.',
      '`await` pauses execution of that function until the server sends the data, without freezing the browser.',
    ],
    commonMistakes: [
      {
        mistake: 'Using await outside of an async function',
        why: 'await can only be used inside functions declared with the async keyword.',
        solution: 'Add async in front of your function: async function fetchData() { ... }',
      },
    ],
    initialFiles: {
      html: `<div class="quote-box">\n  <h2>Daily Tech Wisdom</h2>\n  <p id="quoteText">Click the button below to fetch inspiration.</p>\n  <span id="quoteAuthor">- System</span>\n  <div style="margin-top: 20px;">\n    <button id="fetchBtn">Fetch New Quote</button>\n  </div>\n</div>`,
      css: `body { font-family: system-ui; background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; min-height: 80vh; }\n.quote-box {\n  background: #1e293b;\n  padding: 32px;\n  border-radius: 16px;\n  max-width: 440px;\n  text-align: center;\n  border: 1px solid #334155;\n  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);\n}\n#quoteText { font-size: 18px; line-height: 1.6; color: #f1f5f9; min-height: 60px; }\n#quoteAuthor { font-size: 14px; color: #94a3b8; font-style: italic; }\n#fetchBtn {\n  background: #3b82f6;\n  color: white;\n  border: none;\n  padding: 10px 24px;\n  border-radius: 8px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 0.2s;\n}\n#fetchBtn:hover { background: #2563eb; }`,
      js: `// Simulated database of quotes\nconst quotes = [\n  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },\n  { text: "Code is like humor. When you have to explain it, it’s bad.", author: "Cory House" },\n  { text: "Simplicity is the soul of efficiency.", author: "Austin Freeman" }\n];\n\n// Write an async function fetchQuote() that picks a quote and updates #quoteText and #quoteAuthor\n`,
    },
    solutionFiles: {
      html: `<div class="quote-box">\n  <h2>Daily Tech Wisdom</h2>\n  <p id="quoteText">Click the button below to fetch inspiration.</p>\n  <span id="quoteAuthor">- System</span>\n  <div style="margin-top: 20px;">\n    <button id="fetchBtn">Fetch New Quote</button>\n  </div>\n</div>`,
      css: `body { font-family: system-ui; background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; min-height: 80vh; }\n.quote-box {\n  background: #1e293b;\n  padding: 32px;\n  border-radius: 16px;\n  max-width: 440px;\n  text-align: center;\n  border: 1px solid #334155;\n  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);\n}\n#quoteText { font-size: 18px; line-height: 1.6; color: #f1f5f9; min-height: 60px; }\n#quoteAuthor { font-size: 14px; color: #94a3b8; font-style: italic; }\n#fetchBtn {\n  background: #3b82f6;\n  color: white;\n  border: none;\n  padding: 10px 24px;\n  border-radius: 8px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 0.2s;\n}\n#fetchBtn:hover { background: #2563eb; }`,
      js: `const quotes = [\n  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },\n  { text: "Code is like humor. When you have to explain it, it’s bad.", author: "Cory House" },\n  { text: "Simplicity is the soul of efficiency.", author: "Austin Freeman" }\n];\n\nconst textEl = document.getElementById("quoteText");\nconst authorEl = document.getElementById("quoteAuthor");\nconst btn = document.getElementById("fetchBtn");\n\nasync function fetchQuote() {\n  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];\n  textEl.textContent = randomQuote.text;\n  authorEl.textContent = "- " + randomQuote.author;\n}\n\nbtn.addEventListener("click", fetchQuote);`,
    },
    instructions: [
      'Select `#quoteText`, `#quoteAuthor`, and `#fetchBtn`.',
      'Create an asynchronous function named `fetchQuote()`.',
      'Pick a random quote from the `quotes` array and update `textContent` for both elements.',
      'Add a `"click"` listener to `#fetchBtn` that calls `fetchQuote`.',
    ],
    expectedGoal: 'Connect #fetchBtn so clicking it updates #quoteText and #quoteAuthor with quotes from the dataset.',
    hints: [
      'Pick a random item: const item = quotes[Math.floor(Math.random() * quotes.length)];',
      'Attach listener: btn.addEventListener("click", fetchQuote);',
    ],
    tests: [
      {
        id: 't-quote-fn',
        description: 'fetchQuote function is defined',
        faultTitle: 'Missing fetchQuote function',
        faultExplanation: 'We could not find a function named fetchQuote.',
        fixSuggestion: 'Write: async function fetchQuote() { ... }',
        type: 'js-eval',
        jsTestExpression: 'typeof fetchQuote === "function"',
      },
      {
        id: 't-quote-click',
        description: 'Clicking #fetchBtn changes the quote text',
        faultTitle: 'Button click not updating quote',
        faultExplanation: 'When we clicked #fetchBtn, #quoteText did not change to a quote from the array.',
        fixSuggestion: 'Make sure btn.addEventListener("click", fetchQuote); is attached.',
        type: 'js-eval',
        jsTestExpression: `(() => {
          const btn = document.getElementById("fetchBtn");
          const p = document.getElementById("quoteText");
          if (!btn || !p) return false;
          btn.click();
          return p.textContent !== "Click the button below to fetch inspiration.";
        })()`,
      },
    ],
    xpReward: 75,
  },
];
