export type TrackId = 'html' | 'css' | 'javascript' | 'frontend' | 'backend';

export interface CodeFiles {
  html: string;
  css: string;
  js: string;
}

export interface CommonMistake {
  mistake: string;
  why: string;
  solution: string;
}

export interface TestCase {
  id: string;
  description: string;
  faultTitle: string;
  faultExplanation: string;
  fixSuggestion: string;
  // evaluation rule details
  type: 'html-contains' | 'html-selector' | 'html-attr' | 'css-property' | 'js-eval' | 'dom-text' | 'custom';
  selector?: string;
  expectedText?: string;
  expectedAttr?: { name: string; valueRegex?: string; required?: boolean };
  expectedCss?: { selector: string; property: string; value: string | string[] };
  jsTestExpression?: string;
  forbiddenRegex?: string;
  requiredRegex?: string;
}

export interface Lesson {
  id: string;
  trackId: TrackId;
  trackTitle: string;
  trackNumber: number;
  order: number;
  title: string;
  subtitle: string;
  category: 'lesson' | 'project';
  difficulty: 'Absolute Beginner' | 'Beginner' | 'Intermediate' | 'Full-Stack';
  estimatedTime: string;
  conceptExplanation: string;
  zeroKnowledgeTips: string[];
  commonMistakes: CommonMistake[];
  initialFiles: CodeFiles;
  solutionFiles: CodeFiles;
  instructions: string[];
  expectedGoal: string;
  hints: string[];
  tests: TestCase[];
  xpReward: number;
}

export interface TestResult {
  id: string;
  description: string;
  passed: boolean;
  faultTitle?: string;
  faultMessage?: string;
  faultExplanation?: string;
  fixSuggestion?: string;
}

export interface StreakData {
  currentStreak: number;
  highestStreak: number;
  lastActiveDate: string; // YYYY-MM-DD
  activeDates: string[]; // List of YYYY-MM-DD
  streakFreezes: number;
  totalXp: number;
  completedLessonIds: string[];
  todayCompletedCount: number;
  dailyGoalTarget: number; // e.g., 1 challenge per day
  earnedBadges: string[];
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  requirement: string;
}

export interface FaultAnalysisResult {
  faultSummary: string;
  beginnerExplanation: string;
  analogy: string;
  actionableTip: string;
  revealedFix?: string;
}

export interface GlossaryTerm {
  term: string;
  tagline: string;
  definition: string;
  example: string;
  track: TrackId | 'general';
}
