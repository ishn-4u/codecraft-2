import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import {
  User,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import { StreakData } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAuthReady: boolean;
  isSigningIn: boolean;
  authError: string | null;
  clearAuthError: () => void;
  signInWithGoogle: (preferRedirect?: boolean) => Promise<void>;
  signOut: () => Promise<void>;
  syncProgressToCloud: (streak: StreakData, codeFilesMap?: Record<string, any>) => Promise<void>;
  loadProgressFromCloud: () => Promise<{ streak?: StreakData; codeMap?: Record<string, any> } | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    // Process redirect result if coming back from redirect sign-in
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          setUser(result.user);
          setAuthError(null);
        }
      })
      .catch((err: any) => {
        console.warn('Redirect sign-in error:', err);
        if (err && err.code && err.code !== 'auth/null-user') {
          setAuthError(getFriendlyErrorMessage(err));
        }
      });

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      setIsAuthReady(true);
      if (currentUser) {
        setAuthError(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const getFriendlyErrorMessage = (error: any): string => {
    if (!error) return 'An error occurred during authentication.';
    const code = error.code || '';
    if (code === 'auth/popup-blocked') {
      return 'The Google sign-in pop-up was blocked by your browser. Please allow popups for this site or use the redirect sign-in option below.';
    }
    if (code === 'auth/popup-closed-by-user') {
      return 'The sign-in window was closed before completing.';
    }
    if (code === 'auth/cancelled-popup-request') {
      return 'Another sign-in window is already active.';
    }
    if (code === 'auth/unauthorized-domain') {
      return `The current domain (${window.location.hostname}) is not authorized in Firebase Authentication.`;
    }
    if (code === 'auth/operation-not-allowed') {
      return 'Google sign-in provider is not enabled in Firebase Console.';
    }
    return error.message || 'Unable to sign in with Google. Please try again.';
  };

  const signInWithGoogle = async (preferRedirect = false) => {
    setIsSigningIn(true);
    setAuthError(null);

    try {
      if (preferRedirect) {
        await signInWithRedirect(auth, googleProvider);
        return;
      }

      // Try popup first
      try {
        await signInWithPopup(auth, googleProvider);
      } catch (popupErr: any) {
        console.warn('Popup sign in failed, testing redirect fallback:', popupErr);
        if (
          popupErr?.code === 'auth/popup-blocked' ||
          popupErr?.code === 'auth/cancelled-popup-request' ||
          popupErr?.message?.includes('popup')
        ) {
          // If popup is blocked, attempt signInWithRedirect automatically
          try {
            await signInWithRedirect(auth, googleProvider);
            return;
          } catch (redirectErr) {
            console.error('Redirect sign in also failed:', redirectErr);
            throw redirectErr;
          }
        }
        throw popupErr;
      }
    } catch (error: any) {
      console.error('Google Sign-In Error:', error);
      setAuthError(getFriendlyErrorMessage(error));
    } finally {
      setIsSigningIn(false);
    }
  };

  const clearAuthError = () => setAuthError(null);

  const signOut = async () => {
    try {
      await firebaseSignOut(auth);
      setAuthError(null);
    } catch (error) {
      console.error('Sign-Out Error:', error);
      throw error;
    }
  };

  const syncProgressToCloud = async (streak: StreakData, codeFilesMap?: Record<string, any>) => {
    if (!user) return;
    const path = `users/${user.uid}`;
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const payload: Record<string, any> = {
        uid: user.uid,
        displayName: user.displayName || 'Coder',
        email: user.email || '',
        photoURL: user.photoURL || '',
        totalXp: streak.totalXp,
        currentStreak: streak.currentStreak,
        highestStreak: streak.highestStreak,
        streakFreezes: streak.streakFreezes,
        lastActiveDate: streak.lastActiveDate,
        activeDates: streak.activeDates,
        completedLessonIds: streak.completedLessonIds,
        todayCompletedCount: streak.todayCompletedCount,
        dailyGoalTarget: streak.dailyGoalTarget,
        earnedBadges: streak.earnedBadges,
        updatedAt: new Date().toISOString(),
      };

      if (codeFilesMap) {
        payload.savedCode = codeFilesMap;
      }

      await setDoc(userDocRef, payload, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const loadProgressFromCloud = async () => {
    if (!user) return null;
    const path = `users/${user.uid}`;
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const snapshot = await getDoc(userDocRef);
      if (snapshot.exists()) {
        const data = snapshot.data();
        const streak: StreakData = {
          currentStreak: data.currentStreak || 0,
          highestStreak: data.highestStreak || data.currentStreak || 0,
          lastActiveDate: data.lastActiveDate || '',
          activeDates: Array.isArray(data.activeDates) ? data.activeDates : [],
          streakFreezes: data.streakFreezes ?? 2,
          totalXp: data.totalXp || 0,
          completedLessonIds: Array.isArray(data.completedLessonIds) ? data.completedLessonIds : [],
          todayCompletedCount: data.todayCompletedCount || 0,
          dailyGoalTarget: data.dailyGoalTarget || 1,
          earnedBadges: Array.isArray(data.earnedBadges) ? data.earnedBadges : [],
        };

        return {
          streak,
          codeMap: data.savedCode || null,
        };
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAuthReady,
        isSigningIn,
        authError,
        clearAuthError,
        signInWithGoogle,
        signOut,
        syncProgressToCloud,
        loadProgressFromCloud,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
