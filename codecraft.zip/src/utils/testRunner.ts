import { CodeFiles, Lesson, TestResult } from '../types';

export function runLessonTests(lesson: Lesson, files: CodeFiles): Promise<{ results: TestResult[]; allPassed: boolean; consoleLogs: string[] }> {
  return new Promise((resolve) => {
    const results: TestResult[] = [];
    const consoleLogs: string[] = [];

    // Create an isolated iframe for clean DOM & CSS testing
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.body.appendChild(iframe);

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!doc) {
      document.body.removeChild(iframe);
      resolve({
        results: lesson.tests.map((t) => ({
          id: t.id,
          description: t.description,
          passed: false,
          faultTitle: 'Sandbox Error',
          faultMessage: 'Could not create preview sandbox.',
          faultExplanation: 'Please refresh the page and try again.',
          fixSuggestion: 'Check your browser settings.',
        })),
        allPassed: false,
        consoleLogs: [],
      });
      return;
    }

    // Intercept console.log from iframe
    const win = iframe.contentWindow as any;
    if (win && win.console) {
      const originalLog = win.console.log;
      win.console.log = (...args: any[]) => {
        const formatted = args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
        consoleLogs.push(formatted);
        if (originalLog) originalLog.apply(win.console, args);
      };
    }

    try {
      // Inject user code into iframe document
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <style>${files.css}</style>
          </head>
          <body>
            ${files.html}
            <script>
              try {
                ${files.js}
              } catch (e) {
                window.__userJsError = e.message;
              }
            <\/script>
          </body>
        </html>
      `);
      doc.close();

      const win = iframe.contentWindow as any;
      const jsRuntimeError = win?.__userJsError;

      // Evaluate each test case
      for (const test of lesson.tests) {
        let passed = false;
        let faultMessage = test.faultExplanation;

        if (jsRuntimeError && (test.type === 'js-eval' || test.type === 'dom-text')) {
          passed = false;
          faultMessage = `JavaScript Error: ${jsRuntimeError}`;
        } else {
          switch (test.type) {
            case 'html-selector': {
              if (test.selector) {
                const el = doc.querySelector(test.selector);
                passed = !!el;
                if (!passed) {
                  faultMessage = `Could not find an element matching selector: "${test.selector}"`;
                }
              }
              break;
            }

            case 'html-contains': {
              if (test.expectedText) {
                passed = Boolean(files.html.includes(test.expectedText) || (files.js && files.js.includes(test.expectedText)));
                if (!passed) {
                  faultMessage = `Expected to find "${test.expectedText}" in your code.`;
                }
              }
              break;
            }

            case 'html-attr': {
              if (test.selector && test.expectedAttr) {
                const el = doc.querySelector(test.selector);
                if (!el) {
                  passed = false;
                  faultMessage = `Element "${test.selector}" was not found.`;
                } else {
                  const attrVal = el.getAttribute(test.expectedAttr.name);
                  if (attrVal === null) {
                    passed = false;
                    faultMessage = `Element "${test.selector}" is missing the "${test.expectedAttr.name}" attribute.`;
                  } else if (test.expectedAttr.valueRegex) {
                    const regex = new RegExp(test.expectedAttr.valueRegex, 'i');
                    passed = regex.test(attrVal);
                    if (!passed) {
                      faultMessage = `Attribute "${test.expectedAttr.name}" has value "${attrVal}", which does not match expected format.`;
                    }
                  } else {
                    passed = true;
                  }
                }
              }
              break;
            }

            case 'dom-text': {
              if (test.selector && test.expectedText) {
                const el = doc.querySelector(test.selector);
                if (!el) {
                  passed = false;
                  faultMessage = `Element "${test.selector}" not found in page.`;
                } else {
                  const actualText = el.textContent?.trim() || '';
                  passed = actualText.toLowerCase() === test.expectedText.trim().toLowerCase();
                  if (!passed) {
                    faultMessage = `Expected text "${test.expectedText}", but found "${actualText}".`;
                  }
                }
              }
              break;
            }

            case 'css-property':
            case 'expected-css' as any: {
              const expectedCss = test.expectedCss;
              if (expectedCss) {
                const el = doc.querySelector(expectedCss.selector);
                if (!el) {
                  passed = false;
                  faultMessage = `Element "${expectedCss.selector}" not found to inspect CSS style.`;
                } else {
                  const computed = win.getComputedStyle(el);
                  const actualVal = computed.getPropertyValue(expectedCss.property);
                  const expectedValues = Array.isArray(expectedCss.value) ? expectedCss.value : [expectedCss.value];
                  
                  // Check direct match or css string includes
                  passed = expectedValues.some((v) => actualVal.toLowerCase().includes(v.toLowerCase()) || files.css.includes(v));
                  if (!passed) {
                    faultMessage = `Property "${expectedCss.property}" on "${expectedCss.selector}" was expected to be "${expectedValues[0]}", but got "${actualVal}".`;
                  }
                }
              }
              break;
            }

            case 'js-eval': {
              if (test.jsTestExpression && win) {
                try {
                  const evalResult = win.eval(test.jsTestExpression);
                  passed = !!evalResult;
                  if (!passed) {
                    faultMessage = test.faultExplanation;
                  }
                } catch (e: any) {
                  passed = false;
                  faultMessage = `Execution check failed: ${e.message}`;
                }
              }
              break;
            }

            default:
              passed = true;
          }
        }

        results.push({
          id: test.id,
          description: test.description,
          passed,
          faultTitle: passed ? undefined : test.faultTitle,
          faultMessage: passed ? undefined : faultMessage,
          faultExplanation: passed ? undefined : test.faultExplanation,
          fixSuggestion: passed ? undefined : test.fixSuggestion,
        });
      }
    } catch (err: any) {
      console.error('Test execution error:', err);
    } finally {
      // Clean up iframe
      if (document.body.contains(iframe)) {
        document.body.removeChild(iframe);
      }
    }

    const allPassed = results.length > 0 && results.every((r) => r.passed);
    resolve({ results, allPassed, consoleLogs });
  });
}
