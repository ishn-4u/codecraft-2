import { Badge, StreakData } from '../types';

const STORAGE_KEY = 'codecraft_user_streak_v1';

export const ALL_BADGES: Badge[] = [
  {
    id: 'first-spark',
    title: 'First Spark',
    description: 'Wrote your very first line of code and passed a test!',
    icon: 'Sparkles',
    category: 'Milestone',
    requirement: 'Complete your 1st challenge',
  },
  {
    id: 'streak-3',
    title: 'Fire Starter',
    description: 'Maintained a 3-day daily coding streak.',
    icon: 'Flame',
    category: 'Streak',
    requirement: '3-day streak',
  },
  {
    id: 'streak-7',
    title: 'Habit Champion',
    description: 'Code every day for a full week!',
    icon: 'Zap',
    category: 'Streak',
    requirement: '7-day streak',
  },
  {
    id: 'html-master',
    title: 'HTML Architect',
    description: 'Completed the foundational HTML fundamentals track.',
    icon: 'FileCode2',
    category: 'Track',
    requirement: 'Complete Track 1',
  },
  {
    id: 'css-stylist',
    title: 'CSS Stylist',
    description: 'Mastered the Box Model, colors, and modern Flexbox layouts.',
    icon: 'Palette',
    category: 'Track',
    requirement: 'Complete Track 2',
  },
  {
    id: 'js-ninja',
    title: 'JavaScript Ninja',
    description: 'Brought pages to life with variables, functions, and DOM events.',
    icon: 'Terminal',
    category: 'Track',
    requirement: 'Complete Track 3',
  },
  {
    id: 'fullstack-explorer',
    title: 'Full-Stack Explorer',
    description: 'Discovered APIs, JSON client-server communication, and dynamic data.',
    icon: 'Server',
    category: 'Track',
    requirement: 'Complete Track 5',
  },
];

export function getTodayDateString(): string {
  const now = new Date();
  return now.toISOString().split('T')[0];
}

export function getYesterdayDateString(): string {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return yesterday.toISOString().split('T')[0];
}

export function loadStreakData(): StreakData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return checkStreakFreshness(parsed);
    }
  } catch (e) {
    console.error('Failed to load streak data:', e);
  }

  // Initial starter data for brand new user
  const initial: StreakData = {
    currentStreak: 1,
    highestStreak: 1,
    lastActiveDate: getTodayDateString(),
    activeDates: [getTodayDateString()],
    streakFreezes: 2,
    totalXp: 0,
    completedLessonIds: [],
    todayCompletedCount: 0,
    dailyGoalTarget: 1,
    earnedBadges: [],
  };
  saveStreakData(initial);
  return initial;
}

export function saveStreakData(data: StreakData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save streak data:', e);
  }
}

export function checkStreakFreshness(data: StreakData): StreakData {
  const today = getTodayDateString();
  const yesterday = getYesterdayDateString();

  if (data.lastActiveDate === today) {
    return data;
  }

  // If last active was yesterday, streak is currently valid and waiting for today's challenge
  if (data.lastActiveDate === yesterday) {
    return {
      ...data,
      todayCompletedCount: 0,
    };
  }

  // If last active was 2 or more days ago
  // Check if we can use a streak freeze
  if (data.streakFreezes > 0 && data.currentStreak > 1) {
    return {
      ...data,
      streakFreezes: data.streakFreezes - 1,
      todayCompletedCount: 0,
    };
  }

  // Otherwise streak resets
  return {
    ...data,
    currentStreak: 0,
    todayCompletedCount: 0,
  };
}

export function recordChallengeCompleted(lessonId: string, xpReward: number): { data: StreakData; newlyEarnedBadges: Badge[]; leveledUp: boolean } {
  const current = loadStreakData();
  const today = getTodayDateString();
  const yesterday = getYesterdayDateString();
  const previousLevel = calculateLevel(current.totalXp).level;

  const isFirstCompletion = !current.completedLessonIds.includes(lessonId);
  const completedLessonIds = isFirstCompletion
    ? [...current.completedLessonIds, lessonId]
    : current.completedLessonIds;

  const addedXp = isFirstCompletion ? xpReward : Math.floor(xpReward * 0.25); // Repeat gives 25% practice XP
  const newTotalXp = current.totalXp + addedXp;

  // Streak calculation
  let newCurrentStreak = current.currentStreak;
  let newHighestStreak = current.highestStreak;
  let activeDates = [...current.activeDates];

  if (!activeDates.includes(today)) {
    activeDates.push(today);
  }

  if (current.lastActiveDate === today) {
    // Already active today, streak stays maintained
  } else if (current.lastActiveDate === yesterday) {
    newCurrentStreak += 1;
  } else {
    newCurrentStreak = 1;
  }

  if (newCurrentStreak > newHighestStreak) {
    newHighestStreak = newCurrentStreak;
  }

  const todayCompletedCount = current.lastActiveDate === today ? current.todayCompletedCount + 1 : 1;

  // Check badges
  const newlyEarnedBadges: Badge[] = [];
  const earnedBadgeIds = [...current.earnedBadges];

  function award(badgeId: string) {
    if (!earnedBadgeIds.includes(badgeId)) {
      earnedBadgeIds.push(badgeId);
      const b = ALL_BADGES.find((x) => x.id === badgeId);
      if (b) newlyEarnedBadges.push(b);
    }
  }

  if (completedLessonIds.length >= 1) award('first-spark');
  if (newCurrentStreak >= 3) award('streak-3');
  if (newCurrentStreak >= 7) award('streak-7');

  if (completedLessonIds.some((id) => id.startsWith('html'))) award('html-master');
  if (completedLessonIds.some((id) => id.startsWith('css'))) award('css-stylist');
  if (completedLessonIds.some((id) => id.startsWith('js'))) award('js-ninja');
  if (completedLessonIds.some((id) => id.startsWith('backend'))) award('fullstack-explorer');

  const updatedData: StreakData = {
    ...current,
    currentStreak: newCurrentStreak,
    highestStreak: newHighestStreak,
    lastActiveDate: today,
    activeDates,
    totalXp: newTotalXp,
    completedLessonIds,
    todayCompletedCount,
    earnedBadges: earnedBadgeIds,
  };

  saveStreakData(updatedData);

  const newLevel = calculateLevel(newTotalXp).level;
  const leveledUp = newLevel > previousLevel;

  return { data: updatedData, newlyEarnedBadges, leveledUp };
}

export function calculateLevel(xp: number): { level: number; title: string; currentLevelXp: number; nextLevelXp: number; progressPercent: number } {
  const levels = [
    { level: 1, title: 'Novice Coder', minXp: 0, maxXp: 100 },
    { level: 2, title: 'Tag Apprentice', minXp: 100, maxXp: 250 },
    { level: 3, title: 'CSS Stylist', minXp: 250, maxXp: 450 },
    { level: 4, title: 'Layout Architect', minXp: 450, maxXp: 750 },
    { level: 5, title: 'JavaScript Wizard', minXp: 750, maxXp: 1100 },
    { level: 6, title: 'Full-Stack Engineer', minXp: 1100, maxXp: 1600 },
    { level: 7, title: 'Code Craftsman', minXp: 1600, maxXp: 2200 },
  ];

  for (const lvl of levels) {
    if (xp < lvl.maxXp) {
      const range = lvl.maxXp - lvl.minXp;
      const earnedInRange = xp - lvl.minXp;
      const progressPercent = Math.min(100, Math.max(0, Math.round((earnedInRange / range) * 100)));
      return {
        level: lvl.level,
        title: lvl.title,
        currentLevelXp: earnedInRange,
        nextLevelXp: range,
        progressPercent,
      };
    }
  }

  return {
    level: 8,
    title: 'Code Master',
    currentLevelXp: xp,
    nextLevelXp: xp,
    progressPercent: 100,
  };
}
