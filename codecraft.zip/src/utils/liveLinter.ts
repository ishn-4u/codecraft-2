export interface LiveLintWarning {
  type: 'html' | 'css' | 'js';
  message: string;
  severity: 'warning' | 'info';
  suggestedFix?: string;
}

export function checkLiveSyntax(language: 'html' | 'css' | 'js', code: string): LiveLintWarning[] {
  const warnings: LiveLintWarning[] = [];
  if (!code || !code.trim()) return warnings;

  if (language === 'html') {
    // Check for common unclosed tags
    const commonTags = ['h1', 'h2', 'h3', 'p', 'a', 'ul', 'ol', 'li', 'button', 'form', 'div', 'span'];
    for (const tag of commonTags) {
      const openRegex = new RegExp(`<${tag}(\\s+[^>]*)?>`, 'gi');
      const closeRegex = new RegExp(`</${tag}>`, 'gi');
      const openMatches = code.match(openRegex) || [];
      const closeMatches = code.match(closeRegex) || [];

      if (openMatches.length > closeMatches.length) {
        warnings.push({
          type: 'html',
          message: `Unclosed <${tag}> tag detected. Did you forget the </${tag}> closing tag?`,
          severity: 'warning',
          suggestedFix: `Add </${tag}> to close it`,
        });
      }
    }

    // Check for closing </img> tag
    if (code.includes('</img>')) {
      warnings.push({
        type: 'html',
        message: 'The <img> tag is self-closing and should not have an </img> closing tag.',
        severity: 'info',
        suggestedFix: 'Remove </img>',
      });
    }

    // Check for href without quotes e.g. href=https://
    if (/href=[^"'\s>]+/i.test(code)) {
      warnings.push({
        type: 'html',
        message: 'Attribute values should be wrapped in quotation marks e.g. href="https://..."',
        severity: 'warning',
      });
    }
  }

  if (language === 'css') {
    // Check unclosed braces
    const openBraces = (code.match(/{/g) || []).length;
    const closeBraces = (code.match(/}/g) || []).length;
    if (openBraces > closeBraces) {
      warnings.push({
        type: 'css',
        message: 'Unclosed curly brace { in CSS. Make sure every { has a matching }.',
        severity: 'warning',
      });
    }

    // Check for missing semicolon before a newline inside rules
    const lines = code.split('\n');
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (
        trimmed &&
        trimmed.includes(':') &&
        !trimmed.endsWith(';') &&
        !trimmed.endsWith('{') &&
        !trimmed.endsWith('}') &&
        !trimmed.startsWith('/*')
      ) {
        warnings.push({
          type: 'css',
          message: `Missing semicolon ';' at the end of declaration: "${trimmed}"`,
          severity: 'warning',
          suggestedFix: 'Add a semicolon ; at the end',
        });
      }
    });
  }

  if (language === 'js') {
    // Check for unclosed parentheses or braces
    const openParen = (code.match(/\(/g) || []).length;
    const closeParen = (code.match(/\)/g) || []).length;
    if (openParen !== closeParen) {
      warnings.push({
        type: 'js',
        message: `Unmatched parentheses: found ${openParen} '(' and ${closeParen} ')'.`,
        severity: 'warning',
      });
    }

    // Check getElementById('#something') with hashtag
    if (/getElementById\(\s*["']#/i.test(code)) {
      warnings.push({
        type: 'js',
        message: 'getElementById does not take a "#" hashtag. Just pass the raw ID name.',
        severity: 'warning',
        suggestedFix: 'Remove the # symbol',
      });
    }
  }

  return warnings;
}
